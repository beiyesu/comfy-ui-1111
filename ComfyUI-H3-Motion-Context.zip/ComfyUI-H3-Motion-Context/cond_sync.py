"""Synchronize Motion Context keyframes after latent upscaling."""

import logging

import torch
import torch.nn.functional as F

from h3_motion_context_compat.nodes import MC_KEY, _pixel_frames, _step_offsets, _video_from_latent

_LOG = logging.getLogger("h3_motion_context")


def _target_block(video, index):
    """Map a pixel-frame coordinate to its H3 video latent step."""
    steps = int(video.shape[2])
    total_frames = _pixel_frames(steps)
    if index < 0 or index >= total_frames:
        return None
    starts = _step_offsets(steps)
    step = max(i for i, start in enumerate(starts) if start <= index)
    return video[:, :, step:step + 1].clone()


def _resized_block(block, height, width):
    """Fallback for a non-head keyframe absent from the current latent."""
    if not isinstance(block, torch.Tensor) or block.ndim != 5:
        return block
    dtype = block.dtype
    device = block.device
    out = []
    for step in range(int(block.shape[2])):
        frame = block[:, :, step].float()
        frame = F.interpolate(
            frame,
            size=(height, width),
            mode="bilinear",
            align_corners=False,
        )
        out.append(frame.to(dtype=dtype, device=device))
    return torch.stack(out, dim=2)


class MiniMaxH3MotionContextSyncUpscale:
    """Match pinned Motion Context blocks to an upscaled AV latent."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "conditioning": ("CONDITIONING",),
                "latent": ("LATENT",),
            }
        }

    RETURN_TYPES = ("CONDITIONING",)
    RETURN_NAMES = ("conditioning",)
    FUNCTION = "sync"
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = (
        "Synchronize H3 Motion Context pinned keyframes to a latent-upscaled "
        "second-pass clip. The current upscaled latent is the preferred block "
        "source; original R2V references are left untouched."
    )

    def sync(self, conditioning, latent):
        video = _video_from_latent(latent)
        height = int(video.shape[3])
        width = int(video.shape[4])
        changed = 0
        result = []
        for item in conditioning:
            cond, params = item
            params = dict(params)
            keyframes = params.get("minimax_keyframes")
            if keyframes:
                synced = []
                for keyframe in keyframes:
                    keyframe = dict(keyframe)
                    source = keyframe.get("latent")
                    index = int(keyframe.get(
                        MC_KEY,
                        keyframe.get("resolved_frame_index", 0),
                    ))
                    block = _target_block(video, index)
                    if block is None and source is not None:
                        block = _resized_block(source, height, width)
                    if block is not None:
                        keyframe["latent"] = block
                        changed += 1
                    synced.append(keyframe)
                params["minimax_keyframes"] = synced
            result.append([cond, params])
        _LOG.info(
            "h3_motion_context: synced %d pinned block(s) to %dx%d",
            changed, width * 16, height * 16,
        )
        return (result,)


NODE_CLASS_MAPPINGS = {
    "MiniMaxH3MotionContextSyncUpscale": MiniMaxH3MotionContextSyncUpscale,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "MiniMaxH3MotionContextSyncUpscale": "H3 Motion Context Sync Upscale",
}
