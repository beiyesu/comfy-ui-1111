"""H3 Motion Context.

Clip chaining for MiniMax H3: pin the tail of the previous clip, picture
and sound, so the next clip genuinely continues it.

This registers the nodes and nothing else. The two ComfyUI patches

  patch_layout   lifts the first/last-only keyframe anchor restriction,
                 moves pinned audio onto the clip's own timeline, and
                 keeps everything aligned when references shift the layout
  patch_payload  stops the refs branch clobbering keyframe cond latents,
                 so pinned video and pinned audio can be used together

install themselves the first time a Motion Context node runs, not at
import. ComfyUI imports every folder in custom_nodes at startup, and
patching there would put this pack's wrappers in the path of every H3
graph on the machine. Installing on first use means having the pack
installed changes nothing until you actually chain a clip.

Both patches are also gated on this pack's own markers, so even once
installed they leave unrelated H3 graphs bit-identical to stock.

The Budget node is pure arithmetic: it turns a desired delivered duration
into an H3-legal sample length and the matching context trim, so chained
clips no longer lose their pinned head from the intended timeline length.
Its optional preserve-tail mode trades exact arbitrary duration for keeping
every newly generated tail frame.

Each patch self-tests against the live ComfyUI code before it commits.
If a test fails the node refuses to run and says why, so an upstream
change produces a clear error rather than a silently wrong render.
"""

import importlib.util
import logging
import sys
import types
from pathlib import Path

_COMPAT_PACKAGE = "h3_motion_context_compat"


def _load_compat_package():
    """Load sibling modules when ComfyUI names this package by file path."""
    package = sys.modules.get(_COMPAT_PACKAGE)
    if package is not None:
        return package

    package = types.ModuleType(_COMPAT_PACKAGE)
    package.__path__ = [str(Path(__file__).resolve().parent)]
    sys.modules[_COMPAT_PACKAGE] = package

    for name in ("patch_layout", "patch_payload", "nodes", "probe_node", "dependency"):
        full_name = f"{_COMPAT_PACKAGE}.{name}"
        if full_name in sys.modules:
            continue
        path = Path(__file__).resolve().parent / f"{name}.py"
        spec = importlib.util.spec_from_file_location(full_name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[full_name] = module
        spec.loader.exec_module(module)
    return package


_compat = _load_compat_package()
_nodes = sys.modules[f"{_COMPAT_PACKAGE}.nodes"]
_probe = sys.modules[f"{_COMPAT_PACKAGE}.probe_node"]
_dependency = sys.modules[f"{_COMPAT_PACKAGE}.dependency"]

NODE_CLASS_MAPPINGS = dict(_nodes.NODE_CLASS_MAPPINGS)
NODE_DISPLAY_NAME_MAPPINGS = dict(_nodes.NODE_DISPLAY_NAME_MAPPINGS)
_PROBE_CLASSES = _probe.NODE_CLASS_MAPPINGS
_PROBE_NAMES = _probe.NODE_DISPLAY_NAME_MAPPINGS
_DEPENDENCY_CLASSES = _dependency.NODE_CLASS_MAPPINGS
_DEPENDENCY_NAMES = _dependency.NODE_DISPLAY_NAME_MAPPINGS

NODE_CLASS_MAPPINGS.update(_PROBE_CLASSES)
NODE_DISPLAY_NAME_MAPPINGS.update(_PROBE_NAMES)
NODE_CLASS_MAPPINGS.update(_DEPENDENCY_CLASSES)
NODE_DISPLAY_NAME_MAPPINGS.update(_DEPENDENCY_NAMES)

logging.getLogger("h3_motion_context").info(
    "h3_motion_context: nodes registered. ComfyUI patches install on the "
    "first run of a Motion Context node.")

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
