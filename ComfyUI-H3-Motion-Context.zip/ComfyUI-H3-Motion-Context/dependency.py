"""Graph-ordering helpers for Motion Context workflows."""


class MiniMaxH3MotionContextDependency:
    """Pass a latent through after another output has been evaluated."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "latent": ("LATENT",),
            },
            "optional": {
                "dependency": ("*",),
            },
        }

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent",)
    FUNCTION = "execute"
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = (
        "Force a downstream latent branch to wait for another output without "
        "changing the latent. Use it to keep a handoff branch from changing "
        "the execution order of the main render branch."
    )

    def execute(self, latent, dependency=None):
        return (latent,)


NODE_CLASS_MAPPINGS = {
    "MiniMaxH3MotionContextDependency": MiniMaxH3MotionContextDependency,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "MiniMaxH3MotionContextDependency": "H3 Motion Context Dependency",
}
