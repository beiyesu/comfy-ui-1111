"""Pin previous-clip motion at the head of an H3 clip.

Wire it between a stock H3 conditioning node and the sampler:

    MiniMaxH3ImageToVideo / MiniMaxH3ReferenceToVideo (or the t2v path)
        -> H3 Motion Context
        -> guider / sampler

Two axes to test, both cheap.

encode_mode
  frames  one VAE call per frame, each pinned as its own cond block. The
          model sees N snapshots at N instants.
  video   one VAE call for the whole run. The H3 video VAE has latent_dim
          3, so it reads the batch axis as time and compresses the run
          into fewer latent steps (5 pixel frames -> 2 steps, 22 -> 7).
          Each step becomes one cond block, so the motion between frames
          lives inside the latent instead of being implied across separate
          stills. Far fewer rows and one VAE load.

anchor_mode
  head    pinned frames occupy indices 0..N-1 of the delivered timeline.
          They come back in the output, so trim that many frames off the
          front before concatenating.
  before  pinned frames sit at negative indices, ending at -1, so
          delivered frame 0 continues from them and nothing is wasted.
          Their time coordinates land below text_len, which is the range
          the text rows occupy. Whether that collision matters is exactly
          what this mode is asking.
"""

import logging
import math
import os
import tempfile

import comfy.utils
import folder_paths
import node_helpers
import torch

try:
    from safetensors.torch import load_file as _st_load, save_file as _st_save
    from safetensors import safe_open as _st_safe_open
except ImportError:  # ComfyUI always ships safetensors; belt and braces
    _st_load = _st_save = None
    _st_safe_open = None

from h3_motion_context_compat.patch_layout import (
    MC_KEY,
    MC_AUDIO_KEY,
    apply_patch as _apply_layout_patch,
    is_applied as _layout_patch_applied,
)
from h3_motion_context_compat.patch_payload import (
    apply_patch as _apply_payload_patch,
    is_applied as _payload_patch_applied,
)

try:
    import torchaudio
except ImportError:
    torchaudio = None

_LOG = logging.getLogger("h3_motion_context")


def _ensure_layout_patch():
    """Install the layout patch, once, the first time a node runs.

    ComfyUI imports every folder in custom_nodes at startup, so patching
    at import time would put this pack's wrappers in the path of every H3
    graph on the machine, including graphs that never go near these
    nodes. Installing on first use instead means the pack sitting in
    custom_nodes changes nothing at all until you actually chain a clip.

    The cost is that a self-test failure shows up on the first render
    rather than in the startup log. The message is the same either way,
    and it still refuses rather than rendering something wrong.
    """
    if _layout_patch_applied():
        return
    if not _apply_layout_patch():
        raise RuntimeError(
            "h3_motion_context: the layout patch could not be applied, so "
            "interior anchors would be rejected by ComfyUI. The reason was "
            "logged just above this error.")


def _ensure_payload_patch():
    """Install the payload patch, once, before anything needs it.

    Reached whenever a Motion Context keyframe can meet a reference block:
    either an audio continuation added by this node, or references already
    present on Ref2VA conditioning. Stock extra_conds lets the latter
    overwrite the keyframe latents, which leaves the packed layout with
    unfilled condition rows.
    """
    if _payload_patch_applied():
        return
    if not _apply_payload_patch():
        raise RuntimeError(
            "h3_motion_context: the payload patch could not be applied. "
            "Without it reference blocks would overwrite the pinned video "
            "latents and the motion context would be lost. The reason was "
            "logged just above this error.")


FRAME_PER_TOKEN = (1, 4, 4, 4, 4)
FPS = 24  # H3's native rate; audio latents run at 40 Hz, hence FRAME_RESCALE 5/3
FRAME_RESCALE = 5.0 / 3.0
AUDIO_HZ = 40.0
CONTEXT_LENGTHS = (5, 22, 39, 56)
DEFAULT_TAPER_CURVE = "0.24,0.24,0.24,0.24,0.24,0.12,0"

# Run lengths the video VAE's downscale formula max(1, (n - 5) // 17 * 5 + 2)
# actually distinguishes. Anything between two grid points encodes to the same
# number of latent steps as the lower one, but the steps then cover the FIRST
# `covered` frames of the input rather than the last: encoding 10 frames yields
# the same 2 steps as encoding 5, representing frames [-10..-6] of the source
# clip instead of [-5..-1]. The pinned run would end five frames early and the
# delivered clip would continue from the wrong instant. So off-grid requests
# are snapped DOWN before slicing, keeping content and coverage in agreement.
# The grid is 17m+5 and continues upward; the node only offers up to 56,
# but the snap-down logic knows the higher points so an out-of-range
# request lands on the nearest real one instead of being clamped to 39.
VIDEO_RUN_GRID = (124, 107, 90, 73, 56, 39, 22, 5, 1)


def _align_sample_frames(frames):
    """Round up to MiniMax H3's native 17k+5 sample grid."""
    n = max(5, int(frames))
    while n % 17 != 5:
        n += 1
    return n


def _context_frames(value):
    """Resolve the UI's context setting, allowing 0 for a chain's first clip."""
    try:
        n = int(value)
    except (TypeError, ValueError):
        n = 22
    return max(0, n)


def _phase_aligned_tail_start(total_steps, n_steps, end_frame):
    """Choose a cycle-aligned window ending at or before ``end_frame``.

    Returns ``(start_step, pin_end_px, gap_after_pin)``. Director continuity
    uses the previous clip's exported end rather than the absolute latent end;
    the gap is the tail that must be removed from the previous export to
    prevent the next clip from echoing it.
    """
    if n_steps > total_steps:
        raise ValueError(
            "h3_motion_context: need %d latent steps, context has %d."
            % (n_steps, total_steps))
    if end_frame is None:
        start = total_steps - n_steps
        if start % 5 != 0:
            raise RuntimeError(
                "h3_motion_context: tail start cycle %d != 0; refusing a "
                "shifted join." % (start % 5))
        return start, _pixel_frames(total_steps), 0

    end_limit = int(end_frame)
    best_start = None
    best_end = -1
    for start in range(0, total_steps - n_steps + 1, 5):
        start_px = _pixel_frames(start)
        end_px = start_px + _pixel_frames(n_steps)
        if end_px <= end_limit and end_px >= best_end:
            best_start = start
            best_end = end_px
    if best_start is None:
        raise RuntimeError(
            "h3_motion_context: no phase-aligned %d-step window ends at or "
            "before frame %d." % (n_steps, end_limit))
    return best_start, best_end, max(0, end_limit - best_end)


def _latent_strength_curve(setting, selected_steps, strength, taper):
    """Resolve an explicit per-step curve, or the legacy auto taper.

    Explicit entries are absolute latent RMS strengths. A short list is
    zero-padded so ``0.24,0.24`` and a full seven-entry vector mean the
    same thing for a 22-frame context.
    """
    text = "auto" if setting is None else str(setting).strip()
    if text.lower() == "auto":
        factors = [
            max(0.0, (taper - index) / taper) if taper else 0.0
            for index in range(selected_steps)
        ]
        return [strength * factor for factor in factors], "auto"

    if text.startswith("[") and text.endswith("]"):
        text = text[1:-1].strip()
    if not text:
        raise ValueError(
                "h3_motion_context: strength_curve is empty; use auto or a "
                "comma-separated list such as 0.24,0.24,0")

    entries = text.split(",")
    if len(entries) > selected_steps:
        raise ValueError(
            "h3_motion_context: strength_curve has %d entries, but the "
            "selected context has only %d latent steps." %
            (len(entries), selected_steps))

    values = []
    for index, entry in enumerate(entries):
        try:
            value = float(entry)
        except ValueError as exc:
            raise ValueError(
                "h3_motion_context: strength_curve entry %d (%r) is not "
                "a number." % (index + 1, entry.strip())) from exc
        if not math.isfinite(value) or value < 0.0:
            raise ValueError(
                "h3_motion_context: strength_curve entry %d must be finite "
                "and non-negative." % (index + 1))
        values.append(value)
    return values + [0.0] * (selected_steps - len(values)), "explicit"


def _video_vae_images(pixels):
    """Convert a video VAE tensor to ComfyUI's IMAGE layout.

    ComfyUI's video VAE wrapper returns ``[B, T, H, W, C]``. IMAGE collapses
    batch and time, matching stock VAEDecode's video conversion.
    """
    if pixels.ndim == 5:
        return pixels.reshape(
            (-1, pixels.shape[-3], pixels.shape[-2], pixels.shape[-1]))
    return pixels


# Settings that used to be widgets. Each had exactly one right answer, so
# offering the wrong one was noise. The losing branches are still in the
# code below: change a constant here to reproduce the failure they cause.
#
#   ENCODE_MODE   "video" encodes the pinned run in one VAE call, so the
#                 motion lives inside the latent. "frames" encodes each
#                 frame as its own still, costs twice the rows and left a
#                 visible seam in testing.
#   ANCHOR_MODE   "head" pins the run at the start of the clip, where the
#                 Trim node removes it. "before" places it at negative
#                 time so nothing needs trimming, but the coordinates
#                 collide with the text rows, which weakens the anchors
#                 and darkens the output.
#   AUDIO_MODE    "timeline" puts the pinned audio on this clip's own
#                 timeline so the model continues it. "ref" is the stock
#                 placement, which the model imitates instead: similar
#                 music, not the same recording, plus a tick at the join.
#   CROP          only ever applied when an aspect ratio changed between
#                 clips, which the resolution check now refuses outright.
ENCODE_MODE = "video"
ANCHOR_MODE = "head"
AUDIO_MODE = "timeline"
CROP = "disabled"


def _pixel_frames(latent_t):
    """Pixel frames covered by latent_t latent steps."""
    return sum(FRAME_PER_TOKEN[k % 5] for k in range(latent_t))


def _step_offsets(latent_t):
    """Pixel-frame index at which each latent step begins."""
    out, acc = [], 0
    for k in range(latent_t):
        out.append(acc)
        acc += FRAME_PER_TOKEN[k % 5]
    return out


def _resize(image, width, height, crop):
    # image [B, H, W, C] -> [B, height, width, 3]; matches the stock helper
    samples = image[..., :3].movedim(-1, 1)
    samples = comfy.utils.common_upscale(samples, width, height, "lanczos", crop)
    return samples.movedim(1, -1)


def _encode_tail_audio(audio_vae, audio, seconds):
    """Encode the last `seconds` of a clip's audio with the H3 audio VAE.

    Returns ([1, 32, 2, T] latent, T) where T counts 40 Hz latent steps,
    matching what the layout calls ref_audio_t.
    """
    waveform = audio["waveform"]  # [B, C, L]
    sr = int(audio["sample_rate"])
    vae_sr = int(getattr(audio_vae, "audio_sample_rate", 32000))
    if sr != vae_sr:
        if torchaudio is None:
            raise RuntimeError(
                "h3_motion_context: context_audio is %d Hz but the VAE wants %d Hz "
                "and torchaudio is not available to resample." % (sr, vae_sr))
        waveform = torchaudio.functional.resample(waveform, sr, vae_sr)
    want = int(round(seconds * vae_sr))
    have = int(waveform.shape[-1])
    if have < want:
        _LOG.warning("h3_motion_context: context_audio is %.3fs, shorter than the "
                     "%.3fs of pinned video. Pinning what there is.",
                     have / vae_sr, seconds)
    else:
        waveform = waveform[..., have - want:]
    z = audio_vae.encode(waveform[:1].movedim(1, -1))  # [1, 32, 2, T]
    return z, int(z.shape[-1])


def _streams_from_latent(latent):
    """Unpack an H3 AV latent into its contained streams.

    NestedTensor.__getitem__ broadcasts the index into every contained
    tensor rather than selecting one, so samples[0] would strip the batch
    dimension off both streams. unbind() returns the pair.
    """
    samples = latent["samples"]
    if hasattr(samples, "unbind"):
        parts = list(samples.unbind())
    elif isinstance(samples, (tuple, list)):
        parts = list(samples)
    else:
        raise ValueError(
            "h3_motion_context: expected a MiniMax H3 AV latent (a nested "
            "video/audio pair), got %r" % type(samples))
    if not parts:
        raise ValueError("h3_motion_context: AV latent contains no streams")
    return parts


def _video_from_latent(latent):
    """Pull the video stream out of an H3 AV latent."""
    video = _streams_from_latent(latent)[0]
    if video.ndim == 4:  # unbatched [C,T,H,W]
        video = video.unsqueeze(0)
    if video.ndim != 5:
        raise ValueError("h3_motion_context: expected video latent [B,C,T,H,W], "
                         "got shape %s" % (tuple(video.shape),))
    return video


def _steps_for_frames(n):
    """Latent steps covering exactly n pixel frames from cycle position 0.

    Returns None when no whole number of steps covers n. The video VAE's
    steps alternate 1, 4, 4, 4, 4 pixel frames, so only certain totals are
    reachable: 1, 5, 9, ... and of the windows this node offers, 5, 22, 39
    and 56 land on 2, 7, 12 and 17 steps. The 1-frame window does not,
    because the last step of a clip spans 4 frames, not 1.
    """
    k, covered = 0, 0
    while covered < n:
        covered += FRAME_PER_TOKEN[k % 5]
        k += 1
    return k if covered == n else None


def _video_tail_from_latent(latent, n, end_frame=None):
    """Slice a phase-aligned run out of a generated H3 latent.

    Returns ``(blocks, offsets, covered, pin_end_px, gap_after_pin)`` in the
    same block shape the encode path produces. With ``end_frame=None`` this is
    the absolute latent tail used by legacy chains. Director-aligned chains
    pass the previous clip's exported sample-timeline end instead.

    This is only sound because the tail window always starts at cycle
    position 0. A clip is 17g+5 frames, which is 5g+2 latent steps; the
    windows are 2, 7, 12 and 17 steps; and 5g+2 minus any of those is a
    multiple of 5. So the sliced run has the same 1, 4, 4, 4, 4 phase as a
    freshly encoded one and _step_offsets applies unchanged. Asserted
    below rather than assumed, because if it ever stopped holding the
    pinned content would silently disagree with the positions written for
    it and the join would land at the wrong instant.
    """
    video = _video_from_latent(latent)
    total = int(video.shape[2])
    steps = _steps_for_frames(n)
    if steps is None:
        raise ValueError(
            "h3_motion_context: a %d frame window is not a whole number of "
            "latent steps, so it cannot be sliced from a latent. Use 5, 22, "
            "39 or 56, or unwire context_latent to encode pixels." % n)
    if steps > total:
        raise ValueError(
            "h3_motion_context: asked for %d latent steps, context_latent "
            "has %d." % (steps, total))
    start, pin_end, gap = _phase_aligned_tail_start(total, steps, end_frame)
    covered = _pixel_frames(steps)
    if covered != n:
        raise RuntimeError(
            "h3_motion_context: %d steps cover %d frames, expected %d."
            % (steps, covered, n))
    blocks = [video[:1, :, start + k:start + k + 1].clone()
              for k in range(steps)]
    return blocks, _step_offsets(steps), covered, pin_end, gap


def _audio_tail_from_latent(latent, a_frames, end_frame=None):
    """Slice the last `a_frames` worth of audio steps straight out of a
    generated H3 latent, skipping the decode -> re-encode round trip.

    Returns (tail latent [1, C, 2, rt], rt, overhang) where rt counts
    40 Hz latent steps and overhang is the signed fraction of a step by
    which the clip's audio grid overshoots its last pixel frame.

    H3 rounds the audio grid to the NEAREST step, not up, so overhang is
    negative for a third of legal clip lengths. 5/3 of a frame count
    lands on .0, .333 or .667 and never on .5, so there are exactly three
    cases:

        frames % 3 == 0   124 -> n/a          exact, overhang  0
        frames % 3 == 1   124 wants 206.67, allocates 207, overhang +1/3
        frames % 3 == 2   260 wants 433.33, allocates 433, overhang -1/3

    A positive overhang means the latent's final step reaches past the
    last frame, a negative one means it stops short. Either way the
    caller compensates the placement with it, so the pinned content lands
    where its samples actually sit. The decoded-audio path never sees
    this because match_tail cuts at the frame.
    """
    parts = _streams_from_latent(latent)
    if len(parts) < 2:
        raise ValueError(
            "h3_motion_context: context_latent has no audio stream. Wire the "
            "sampler output of an H3 AV graph, not a video-only latent.")
    video, audio = parts[0], parts[1]
    if video.ndim == 4:
        video = video.unsqueeze(0)
    if audio.ndim == 3:  # unbatched [C,2,T]
        audio = audio.unsqueeze(0)
    if audio.ndim != 4:
        raise ValueError("h3_motion_context: expected audio latent [B,C,2,T], "
                         "got shape %s" % (tuple(audio.shape),))
    total_t = int(audio.shape[-1])
    frames = _pixel_frames(int(video.shape[2]))
    overhang = total_t - FRAME_RESCALE * frames
    # legal values are exactly 0, +1/3 and -1/3; the band is the widest
    # one that admits all three and still rejects a grid that is out by a
    # whole step or more
    if not (0.0 <= overhang < 1.0):
        _LOG.warning(
            "h3_motion_context: context_latent audio grid is unexpected "
            "(%d steps for %d frames); assuming no overhang.", total_t, frames)
        overhang = 0.0
    rt = int(round(a_frames / float(FPS) * AUDIO_HZ))
    if rt > total_t:
        _LOG.warning("h3_motion_context: asked for %d audio steps, the latent "
                     "has %d. Pinning all of it.", rt, total_t)
        rt = total_t
    if rt < 1:
        raise ValueError("h3_motion_context: audio window is empty")
    if end_frame is None:
        audio_end = total_t
    else:
        audio_end = int(round(float(end_frame) / float(FPS) * AUDIO_HZ))
        audio_end = max(rt, min(total_t, audio_end))
    audio_start = audio_end - rt
    if audio_start < 0:
        audio_start = 0
        rt = audio_end
    tail = audio[:1, ..., audio_start:audio_end].clone()
    return tail, rt, float(overhang)


class MiniMaxH3MotionContext:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "conditioning": ("CONDITIONING",),
                "vae": ("VAE",),
                "latent": ("LATENT",),
                "context_length": (["22", "5", "39", "56"], {
                    "default": "22",
                    "tooltip": "Frames of the previous clip's picture to "
                               "carry over. Only these lengths are whole "
                               "numbers of latent steps, so only these are "
                               "offered. 5 is just barely fluid, 22 is "
                               "nearly seamless. Longer windows pin more "
                               "motion but come off the front of the "
                               "delivered clip, so 56 spends 2.3 seconds of "
                               "the render on frames you throw away."}),
                "audio_context_length": ("INT", {
                    "default": 24, "min": 0, "max": 240,
                    "tooltip": "Frames of tail audio to pin, independent of "
                               "the picture window. 0 follows it. The window "
                               "is END-aligned with the pinned video, so "
                               "this only controls how far back the sound "
                               "reaches. Multiples of 3 land exactly on the "
                               "40 Hz audio grid and multiples of 24 are "
                               "whole seconds: 24 pins the last second. "
                               "Off-grid values are widened to the nearest "
                               "whole step."}),
            },
            "optional": {
                "context_frames": ("IMAGE", {
                    "tooltip": "Decoded frames of the previous clip. Used "
                               "when no context_latent is wired. When one "
                               "is, the picture comes from it instead and "
                               "this is ignored."}),
                "context_latent": ("LATENT", {
                    "tooltip": "Previous clip's SAMPLER OUTPUT latent (the "
                               "same one you wire into the decode nodes). "
                               "Supplies both picture and sound, sliced "
                               "straight out, skipping the decode and "
                               "re-encode that cost a little quality at "
                               "every link of a chain. Must be the same "
                               "resolution as the clip being generated."}),
                "audio_vae": ("VAE", {
                    "tooltip": "H3 audio VAE. Supply with context_audio to "
                               "carry the previous clip's tail sound across "
                               "the join. Not needed when context_latent is "
                               "wired."}),
                "context_audio": ("AUDIO", {
                    "tooltip": "Audio of the previous clip. The tail "
                               "matching the pinned frames is encoded and "
                               "pinned alongside them. Ignored when "
                               "context_latent is wired."}),
                "context_end_frame": ("INT", {
                    "default": 0, "min": 0, "max": 100000,
                    "tooltip": "Exported sample-timeline end of the previous "
                               "clip: trim_frames + exported frames. Wire "
                               "Load Latent's context_end_frame. Leave 0 for "
                               "legacy absolute-latent-tail chains."}),
                "context_found": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "Wire Load Latent.context_found. False is the "
                               "explicit first-clip path: pass conditioning "
                               "through and pin nothing."}),
                "audio_context_enabled": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "False keeps the latent video context but does "
                               "not pin audio. Use this instead of a negative "
                               "audio_context_length."}),
            },
        }

    RETURN_TYPES = ("CONDITIONING", "INT", "INT")
    RETURN_NAMES = ("conditioning", "trim_frames",
                    "trim_previous_export")
    FUNCTION = "apply"
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = ("Pin a run of consecutive frames from a previous clip as "
                   "never-denoised conditioning rows, so the model reads real "
                   "motion instead of guessing it from a single still. With "
                   "context_latent wired, both picture and sound are sliced "
                   "from the previous clip's latent, skipping the decode and "
                   "re-encode that cost a little quality at every link. Turn "
                   "audio_context_enabled off to use only its video. A "
                   "last_frame anchor on the incoming conditioning is kept "
                   "and pinned alongside the head.")

    def apply(self, conditioning, vae, latent, context_length,
              audio_context_length=24, context_frames=None,
              context_latent=None, audio_vae=None, context_audio=None,
              context_end_frame=0, context_found=True,
              audio_context_enabled=True):
        encode_mode, anchor_mode = ENCODE_MODE, ANCHOR_MODE
        audio_mode, crop = AUDIO_MODE, CROP
        context_length = int(context_length)
        _ensure_layout_patch()

        if context_found is False:
            _LOG.warning(
                "h3_motion_context: no previous latent found; first-clip "
                "path is passing conditioning through with no pinned head.")
            return (conditioning, 0, 0)

        video = _video_from_latent(latent)
        latent_t = int(video.shape[2])
        width = int(video.shape[4]) * 16
        height = int(video.shape[3]) * 16
        frame_count = _pixel_frames(latent_t)

        # Decide where the pinned VIDEO comes from before anything else,
        # because it decides how many frames are even available. Slicing it
        # out of the previous clip's latent removes an h264 decode and a
        # VAE encode from the path, and the blocks come out bit-identical
        # to what the model produced rather than a reconstruction of it.
        # A wired latent supplies the picture as well as the sound: the
        # pinned blocks are then exactly the steps the model produced,
        # with no h264 decode, no resize and no VAE round trip to shift
        # colour or contrast. Frames are the path when no latent is wired.
        if context_latent is not None:
            src_video = _video_from_latent(context_latent)
            src_w = int(src_video.shape[4]) * 16
            src_h = int(src_video.shape[3]) * 16
            if src_w != width or src_h != height:
                # a latent cannot be resized. Falling back to frames here
                # would quietly take the lossy path on a graph the user
                # thinks is fine, and a resolution change mid-chain is
                # nearly always a mistake, so say so instead.
                raise ValueError(
                    "h3_motion_context: context_latent is %dx%d but this "
                    "clip is %dx%d. A latent cannot be resized, so the "
                    "previous clip has to be regenerated at this "
                    "resolution, or the chain restarted here."
                    % (src_w, src_h, width, height))
            if int(src_video.shape[1]) != int(video.shape[1]):
                raise ValueError(
                    "h3_motion_context: context_latent has %d channels, "
                    "this clip has %d. That is not an H3 video latent from "
                    "the same model."
                    % (int(src_video.shape[1]), int(video.shape[1])))
            available = _pixel_frames(int(src_video.shape[2]))
            if context_end_frame:
                available = min(
                    available, max(0, int(context_end_frame)))
            video_src = "latent"
        else:
            if context_frames is None:
                raise ValueError(
                    "h3_motion_context: nothing to pin. Wire context_latent "
                    "(preferred) or context_frames.")
            available = int(context_frames.shape[0])
            video_src = "pixels"

        n = min(int(context_length), available)
        if n < 1:
            raise ValueError("h3_motion_context: no frames available to pin")
        if n < context_length:
            _LOG.warning("h3_motion_context: only %d frames available, pinning %d",
                         available, n)

        if encode_mode == "video":
            # snap down to the VAE grid BEFORE slicing, so the frames encoded
            # are exactly the frames the latent steps will cover (see
            # VIDEO_RUN_GRID). Slicing the last n and letting the VAE keep the
            # first `covered` of them would pin a run ending before the clip
            # does, and the join would jump by the difference.
            run = next(g for g in VIDEO_RUN_GRID if g <= n)
            if run != n:
                _LOG.warning(
                    "h3_motion_context: %d frames is off the VAE grid; pinning "
                    "the last %d instead (usable runs: 1, 5, 22, 39, 56)", n, run)
            n = run

        if n >= frame_count:
            raise ValueError(
                "h3_motion_context: asked to pin %d frames into a %d frame clip. "
                "The pinned run must be a small fraction of the timeline."
                % (n, frame_count))

        if video_src == "latent" and _steps_for_frames(n) is None:
            # every window the node offers is a whole number of steps, so
            # reaching this means the grid moved underneath us
            raise RuntimeError(
                "h3_motion_context: a %d frame window is not a whole number "
                "of latent steps. VIDEO_RUN_GRID no longer matches the "
                "VAE; refusing rather than rendering a shifted join." % n)

        if video_src == "latent":
            blocks, offsets, covered, pin_end_px, trim_previous_export = \
                _video_tail_from_latent(
                    context_latent, n,
                    None if not context_end_frame else int(context_end_frame))
            span = covered
            # Even with audio off, a Ref2VA graph can already carry image or
            # video references. Stock extra_conds would replace this list of
            # keyframe latents with those references, leaving the packed
            # layout with condition rows it cannot fill.
            _ensure_payload_patch()
        else:
            # the LAST n frames of the incoming clip become the pinned run
            tail = _resize(context_frames[available - n:], width, height, crop)

        if video_src == "pixels" and encode_mode == "video":
            # one call; the VAE reads the batch axis as time and compresses
            enc = vae.encode(tail)
            if getattr(enc, "ndim", 0) != 5:
                raise ValueError(
                    "h3_motion_context: video-mode encode returned shape %s, "
                    "expected [B,C,T,H,W]. Try encode_mode=frames."
                    % (tuple(getattr(enc, "shape", ())),))
            steps = int(enc.shape[2])
            offsets = _step_offsets(steps)
            covered = _pixel_frames(steps)
            if covered != n:
                # n was snapped to the grid above, so a mismatch here means
                # the VAE's downscale formula changed underneath us and the
                # pinned content no longer lines up with the positions we
                # would write. Refuse rather than render a shifted join.
                raise RuntimeError(
                    "h3_motion_context: %d frames encoded to %d latent steps "
                    "covering %d frames; the VAE grid no longer matches "
                    "VIDEO_RUN_GRID. Upstream VAE change, refusing to run."
                    % (n, steps, covered))
            blocks = [enc[:, :, k:k + 1] for k in range(steps)]
            span = covered
            pin_end_px = available
            trim_previous_export = 0
        elif video_src == "pixels":
            blocks, offsets = [], []
            for i in range(n):
                blocks.append(vae.encode(tail[i:i + 1]))
                offsets.append(i)
            span = n

        if anchor_mode == "before":
            indices = [o - span for o in offsets]
        else:
            indices = list(offsets)

        keyframes = []
        for p, blk in zip(indices, blocks):
            keyframes.append({
                # stock code accepts only 0 or frame_count-1 here; the real
                # position rides under MC_KEY and the layout patch applies it
                "resolved_frame_index": 0,
                MC_KEY: p,
                "latent": blk,
            })

        ref_audio_t = 0
        audio_ref = None
        a_frames = 0
        audio_src = "off"
        if ((context_latent is not None or context_audio is not None)
                and audio_context_enabled is not False):
            _ensure_payload_patch()
            # the audio window is independent of the video one: audio cond
            # rows cost rows but never cost delivered frames
            a_frames = int(audio_context_length) or span
            if context_latent is not None:
                if context_audio is not None:
                    _LOG.info("h3_motion_context: both context_latent and "
                              "context_audio wired; using the latent (skips "
                              "one VAE round trip).")
                audio_latent, ref_audio_t, overhang = _audio_tail_from_latent(
                    context_latent, a_frames,
                    None if pin_end_px is None else pin_end_px)
                audio_src = "latent"
            else:
                if audio_vae is None:
                    raise ValueError(
                        "h3_motion_context: context_audio supplied without "
                        "audio_vae. Wire the H3 audio VAE, or wire "
                        "context_latent instead.")
                audio_latent, ref_audio_t = _encode_tail_audio(
                    audio_vae, context_audio, a_frames / float(FPS))
                overhang = 0.0  # decoded audio was match_tail-cut at the frame
                audio_src = "vae"
            ref = {
                "kind": "audio",
                "ref_audio_t": ref_audio_t,
                "audio_latent": audio_latent,
            }
            if audio_mode == "timeline":
                # end-align the audio window with the pinned video: both are
                # the tail of clip A, so both must end at the same instant
                # of the new timeline -- frame `span` in head mode (where
                # A's last frame sits), frame 0 in before mode. On the
                # latent path the sliced content overshoots A's last
                # frame by `overhang` of a step, signed, because H3
                # rounds its audio grid to the nearest step and so falls
                # short as often as it reaches past. The end coordinate
                # moves by exactly that much; the layout patch takes a
                # fractional frame index.
                end_frame = float(span if anchor_mode == "head" else 0)
                end_frame += overhang / FRAME_RESCALE
                # then snap the window onto the target's own audio grid.
                # The end coordinate is FRAME_RESCALE * end_frame, and
                # FRAME_RESCALE is 5/3, so unless that product happens to
                # be a whole number the pinned rows land between the
                # integer coordinates the target's audio rows occupy. A
                # third of a step is 8.3 ms, which is the size of the
                # constant late offset measured on chained clips. Whether
                # it lands on or off the grid depends on the window
                # length, the path, and the clip's own grid overhang, so
                # it cycles rather than staying put. Rounding the end
                # coordinate to the nearest integer costs at most a third
                # of a step of placement and puts the pinned content on
                # the same grid as the sound being generated from it.
                end_coord = round(FRAME_RESCALE * end_frame)
                end_frame = end_coord / FRAME_RESCALE
                ref[MC_AUDIO_KEY] = end_frame
            # APPEND rather than assign. Ref2VA conditioning already
            # carries the graph's own image, video and audio reference
            # blocks, and assigning minimax_refs outright would replace
            # the lot. Applied as a second call so the keyframe values
            # land first and this one only touches the reference list.
            audio_ref = ref

        # MERGE with any keyframes already on the conditioning instead of
        # replacing them. A last_frame anchor from the upstream node is a
        # legitimate companion to a chained head: the pinned run decides
        # how the clip starts, the anchor decides where it ends. Each kept
        # keyframe is tagged with its own position under MC_KEY so the
        # layout patch gives it the same reference compensation as ours;
        # untagged it would either trip the mixed-keyframe guard (with
        # audio) or sit uncompensated next to compensated anchors (without).
        # At p = frame_count-1 the patch reproduces stock's coordinate bit
        # for bit, so tagging changes nothing when no reference is present.
        # Anchors inside the pinned head are dropped: the pinned run
        # already decides those frames, and a second cond block at the
        # same coordinate would fight it.
        head_end = span if anchor_mode == "head" else 0
        dropped = []
        merged = list(keyframes)
        extra = conditioning[0][1] if conditioning else {}
        prior = extra.get("minimax_keyframes") or []
        pfc = extra.get("minimax_frame_count")
        if prior and pfc is not None and int(pfc) != frame_count:
            raise ValueError(
                "h3_motion_context: the conditioning carries keyframes "
                "resolved for a %d frame clip, but the latent is %d "
                "frames. Wire the conditioning and the latent from the "
                "same node." % (int(pfc), frame_count))
        for kf in prior:
            p = int(kf.get(MC_KEY, kf.get("resolved_frame_index", 0)))
            if p < head_end:
                dropped.append(p)
                continue
            kf = dict(kf)
            kf[MC_KEY] = p
            merged.append(kf)
        out = node_helpers.conditioning_set_values(
            conditioning,
            {
                "minimax_keyframes": merged,
                "minimax_frame_count": frame_count,
            },
        )
        if dropped:
            _LOG.warning(
                "h3_motion_context: dropped %d keyframe anchor(s) at "
                "frame(s) %s: the pinned head already decides frames "
                "0..%d. A last_frame anchor is kept.",
                len(dropped), sorted(set(dropped)), head_end - 1)

        if audio_ref is not None:
            out = node_helpers.conditioning_set_values(
                out, {"minimax_refs": [audio_ref]}, append=True)

        trim = span if anchor_mode == "head" else 0
        _LOG.info("h3_motion_context: video from %s, %s/%s, %d frames -> %d "
                  "cond blocks at indices %d..%d, %d frame clip at %dx%d, "
                  "trim %d, audio %s",
                  video_src, encode_mode, anchor_mode, n, len(blocks),
                  indices[0], indices[-1], frame_count, width, height, trim,
                  ("%d frames -> %d latent steps (%.3fs) from %s, %s"
                   % (a_frames, ref_audio_t, ref_audio_t / AUDIO_HZ, audio_src,
                      "on the timeline ending at frame %.3f"
                      % float(ref.get(MC_AUDIO_KEY))
                      if audio_mode == "timeline" else "stock ref placement"))
                  if ref_audio_t else "off")
        return (out, trim, trim_previous_export)


class MiniMaxH3MotionContextTrim:
    """Drop the pinned head off a decoded clip, picture and sound together.

    The pinned frames occupy the start of the delivered timeline, so they
    have to come off before concatenating. Trimming only the images would
    leave the audio a full trim_frames longer than the video, and muxing
    those puts the whole soundtrack ahead of the picture by trim_frames/24
    seconds. At 5 frames that is 208ms, silent on ambience but squarely
    offbeat on anything with a pulse.

    So this takes both streams and removes the same span from each: whole
    frames from the images, the matching number of samples from the
    waveform. Wire trim_frames from the motion context node so the count
    follows whatever the encoder actually produced.

    The tail needs the same treatment for a different reason. H3's audio
    latent runs at 40 Hz against 24 fps picture, and FRAME_RESCALE is 5/3,
    so the grid rarely lands on a frame boundary. It rounds to the
    NEAREST step, which means a clip ships either about 8.3 ms more sound
    than picture or about 8.3 ms less, depending on its length:

        frames % 3 == 0   exact
        frames % 3 == 1   124 wants 206.67 steps, gets 207, sound is long
        frames % 3 == 2   260 wants 433.33 steps, gets 433, sound is short

    Either way the error compounds. Concatenate two clips and the second
    seam is out by 16.7 ms, three and it is 25 ms, and it grows without
    bound down a chain. It reads as a faint dampening at the first join
    and a short click at later ones. Matching the tail to exactly
    frames/fps stops it accumulating: a long tail is truncated, a short
    one is zero-padded. The padded samples are sound the model never
    generated, so silence is the only honest fill.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "trim_frames": ("INT", {"default": 0, "min": 0, "max": 4096}),
            },
            "optional": {
                "audio": ("AUDIO", {
                    "tooltip": "Decoded audio for the same clip. Trimmed by the "
                               "matching duration so sound stays locked to "
                               "picture. Leave unwired for silent clips."}),
                "fps": ("FLOAT", {
                    "default": 24.0, "min": 1.0, "max": 240.0, "step": 0.001,
                    "tooltip": "Frame rate used to convert the trim into an "
                               "audio duration. Must match what you feed "
                               "Create Video."}),
                "target_frames": ("INT", {
                    "default": 0, "min": 0, "max": 100000,
                    "tooltip": "Exact exported frame count. Wire Budget's "
                               "delivered_frames. 0 keeps sample_length - "
                               "trim_frames."}),
                "match_tail": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "Make the audio duration equal frames/fps "
                               "exactly, trimming a long tail or padding a "
                               "short one with silence. H3 rounds its audio "
                               "grid to the nearest step, so each clip "
                               "carries about 8ms too much or too little "
                               "sound, which accumulates at every join in a "
                               "chain."}),
            },
        }

    RETURN_TYPES = ("IMAGE", "AUDIO")
    RETURN_NAMES = ("images", "audio")
    FUNCTION = "trim"
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = ("Remove the leading pinned frames from a decoded H3 clip, "
                   "trimming picture and sound by the same duration.")

    def trim(self, images, trim_frames, audio=None, fps=24.0,
             target_frames=0, match_tail=True):
        n = max(0, int(trim_frames))
        total = int(images.shape[0])
        if n >= total:
            raise ValueError(
                "h3_motion_context: asked to trim %d frames from a %d frame clip"
                % (n, total))
        out_images = images[n:] if n else images
        target = max(0, int(target_frames))
        if target and int(out_images.shape[0]) > target:
            out_images = out_images[:target]

        out_audio = audio
        if audio is not None:
            waveform = audio["waveform"]
            sr = int(audio["sample_rate"])
            seconds = n / float(fps)
            cut = int(round(seconds * sr))
            length = int(waveform.shape[-1])
            if cut >= length:
                raise ValueError(
                    "h3_motion_context: trimming %.3fs from %.3fs of audio would "
                    "leave nothing. Check that fps matches the clip."
                    % (seconds, length / sr))
            waveform = waveform[..., cut:]

            if match_tail:
                frames_left = int(out_images.shape[0])
                want = int(round(frames_left / float(fps) * sr))
                have = int(waveform.shape[-1])
                if have > want:
                    over = have - want
                    waveform = waveform[..., :want]
                    _LOG.info("h3_motion_context: tail trimmed %d samples "
                              "(%.2fms) so audio matches %d frames exactly",
                              over, over / sr * 1000.0, frames_left)
                elif have < want:
                    # Match Director continuity: a short decoded tail stays
                    # short. Fabricated silence is not part of its handoff.
                    pass

            out_audio = {"waveform": waveform, "sample_rate": sr}
            _LOG.info("h3_motion_context: %d frames / %.4fs picture, %.4fs sound, "
                      "drift %.2fms",
                      total - n, (total - n) / float(fps),
                      int(waveform.shape[-1]) / sr,
                      abs((total - n) / float(fps) - int(waveform.shape[-1]) / sr) * 1000.0)
        elif n:
            _LOG.info("h3_motion_context: trimmed %d leading frames, %d remain. "
                      "No audio wired; if this clip has sound, mux it through "
                      "this node or it will run %.3fs ahead of the picture.",
                      n, total - n, n / float(fps))

        return (out_images, out_audio)


class MiniMaxH3MotionContextTrimExportTail:
    """Remove the previous export tail skipped by phase alignment."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "trim_frames": ("INT", {
                    "default": 0, "min": 0, "max": 100000,
                    "tooltip": "Wire Motion Context's "
                               "trim_previous_export output."}),
            },
            "optional": {
                "audio": ("AUDIO",),
                "fps": ("FLOAT", {
                    "default": 24.0, "min": 1.0, "max": 240.0,
                    "step": 0.001}),
            },
        }

    RETURN_TYPES = ("IMAGE", "AUDIO")
    RETURN_NAMES = ("images", "audio")
    FUNCTION = "trim"
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = ("Trim the phase-alignment gap from the previous exported "
                   "clip, picture and sound together, before concatenating it "
                   "with the newly generated clip.")

    def trim(self, images, trim_frames, audio=None, fps=24.0):
        n = max(0, int(trim_frames))
        total = int(images.shape[0])
        if n >= total:
            raise ValueError(
                "h3_motion_context: cannot drop %d tail frames from a %d "
                "frame export." % (n, total))
        keep = total - n
        out_images = images[:keep] if n else images
        out_audio = audio
        if audio is not None:
            waveform = audio["waveform"]
            sr = int(audio["sample_rate"])
            want = int(round(keep / float(fps) * sr))
            if int(waveform.shape[-1]) > want:
                waveform = waveform[..., :want]
            out_audio = {"waveform": waveform, "sample_rate": sr}
        return (out_images, out_audio)


class MiniMaxH3MotionContextBudget:
    """Plan a sample length that survives the pinned-head trim.

    A chained clip is sampled at ``length`` frames, then the Motion Context
    Trim node removes the pinned head. Planning only the desired delivered
    length therefore makes every chained clip shorter than intended. This
    node chooses an H3-legal sample length from the desired delivered length
    and context window, so ``sample_length - trim_frames`` is the length the
    file will actually contain.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "desired_frames": ("INT", {
                    "default": 120, "min": 5, "max": 100000,
                    "tooltip": "Minimum frames you want in the delivered clip "
                               "after the pinned head is trimmed."}),
                "context_length": ([str(x) for x in CONTEXT_LENGTHS] + ["0"], {
                    "default": "22",
                    "tooltip": "Video context used by this clip. Use 0 for "
                               "the first clip of a chain, when nothing is "
                               "pinned and nothing is trimmed."}),
            },
            "optional": {
                "context_available": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "Wire Load Latent.context_found. When false, "
                               "budget this clip as a first clip even if the "
                               "selected context length is nonzero."}),
                "preserve_tail": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "Keep every newly generated tail frame. The "
                               "delivered length becomes sample_length minus "
                               "the pinned head, rounded up to H3's grid "
                               "instead of cropping the sample overshoot."}),
            },
        }

    RETURN_TYPES = ("INT", "INT", "INT", "INT")
    RETURN_NAMES = ("sample_length", "trim_frames",
                    "delivered_frames", "added_frames")
    FUNCTION = "budget"
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = ("Convert a desired delivered clip length into the MiniMax "
                   "H3 sample length and context trim, so chained clips keep "
                   "their planned duration instead of losing context_length "
                   "frames at every join.")

    def budget(self, desired_frames, context_length,
               context_available=True, preserve_tail=False):
        configured = _context_frames(context_length)
        ctx = 0 if context_available is False else configured
        if ctx != configured:
            _LOG.warning(
                "h3_motion_context: previous latent unavailable; budgeting "
                "with context 0 instead of %d.", configured)
        desired = max(5, int(desired_frames))
        if preserve_tail:
            sample = _align_sample_frames(desired + ctx)
            delivered = sample - ctx
            if delivered < desired:
                raise RuntimeError(
                    "h3_motion_context: sample grid produced %d delivered "
                    "frames, less than the requested %d." %
                    (delivered, desired))
            return (sample, ctx, delivered, delivered - desired)

        # Director first puts the visible/export length on the H3 grid, then
        # budgets the pinned head on top of that visible length.
        visible = _align_sample_frames(desired)
        sample = _align_sample_frames(visible + ctx)
        delivered = sample - ctx
        if delivered < visible:
            raise RuntimeError(
                "h3_motion_context: sample grid produced %d delivered frames, "
                "less than the requested %d." % (delivered, visible))
        # Crop after decode makes delivered exactly the aligned visible plan.
        delivered = visible
        return (sample, ctx, delivered, delivered - desired)


def _resolve_latent_path(path, clip_index=0):
    """Turn the loader's path input into a concrete file.

    Accepts an absolute path, a path relative to ComfyUI's output folder,
    or a directory (in either form). For a directory:

      clip_index == 0   the NEWEST .safetensors inside is used. Simple,
                        but NOT retry-safe: re-rolling a clip loads the
                        rejected attempt's own save (see the node docs).
                        Its run counter also numbers ATTEMPTS, not clips.
      clip_index  > 0   exactly that clip's slot is loaded: clip 1 is
                        *_00001.safetensors. Auto-mode files carry a
                        trailing underscore (*_00001_.safetensors) and
                        are never matched, because their numbers count
                        runs and could hold a reject.
    """
    p = (path or "").strip().strip('"').strip("'")
    if not p:
        p = "h3_context"
    candidates = [p, os.path.join(folder_paths.get_output_directory(), p)]
    for c in candidates:
        if os.path.isfile(c):
            return c
        if os.path.isdir(c):
            idx = int(clip_index)
            if idx > 0:
                # indexed slots use the natural name: clip 2 lives in
                # *_00002.safetensors. Auto-mode files carry a trailing
                # underscore (*_00002_.safetensors) and are deliberately
                # NOT matched: their numbers count runs, not clips, so a
                # reject could be sitting in any of them.
                endings = ("_%05d.safetensors" % idx,
                           "_clip%03d.safetensors" % idx)  # older versions
                files = [os.path.join(c, f) for f in os.listdir(c)
                         if f.endswith(endings)]
                if not files:
                    near = [f for f in os.listdir(c)
                            if f.endswith("_%05d_.safetensors" % idx)]
                    hint = ""
                    if near:
                        hint = (" Found %s, which is an auto-numbered save "
                                "(trailing underscore = numbered by RUN, so "
                                "it may be a reject). If it really is clip "
                                "%d, rename it to drop the trailing "
                                "underscore: %s" %
                                (near[0], idx,
                                 near[0].replace("_%05d_" % idx,
                                                 "_%05d" % idx)))
                    raise FileNotFoundError(
                        "h3_motion_context: no saved latent for clip %d "
                        "(no *_%05d.safetensors in %s).%s"
                        % (idx, idx, c, hint))
            else:
                files = [os.path.join(c, f) for f in os.listdir(c)
                         if f.endswith(".safetensors")]
                if not files:
                    raise FileNotFoundError(
                        "h3_motion_context: no saved latents in %s. Run a "
                        "clip with the Save Latent node first." % c)
            return max(files, key=os.path.getmtime)
    raise FileNotFoundError(
        "h3_motion_context: %r is neither a file nor a folder (also tried "
        "relative to the ComfyUI output directory)." % p)


def _save_latent_atomic(tensors, path, metadata):
    """Replace a latent only after its new safetensors file is complete."""
    folder = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(
        prefix=".%s." % os.path.basename(path), suffix=".part",
        dir=folder)
    os.close(fd)
    try:
        _st_save(tensors, tmp, metadata=metadata)
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


class MiniMaxH3MotionContextSaveLatent:
    """Save an H3 AV latent to disk so the NEXT run can load it.

    Wiring the sampler's output straight into context_latent is a cycle:
    the sampler would be consuming its own result. The latent that motion
    context needs is the PREVIOUS clip's, which lives in the previous run
    -- so it has to cross runs through disk, the same way the frames and
    audio already do. Stock Save/Load Latent can't serialise H3's nested
    video/audio pair; this saves the two streams side by side.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "latent": ("LATENT", {
                    "tooltip": "The sampler's output latent (the same one "
                               "you wire into the decode nodes)."}),
                "filename_prefix": ("STRING", {
                    "default": "h3_context/clip",
                    "tooltip": "Saved under the ComfyUI output folder. The "
                               "default keeps all chain latents in one "
                               "folder so the Load node can always pick "
                               "the newest."}),
                "clip_index": ("INT", {
                    "default": 0, "min": 0, "max": 9999,
                    "tooltip": "Which clip of the chain THIS is. Saves to "
                               "that clip's fixed slot, so a re-roll "
                               "overwrites its own reject instead of "
                               "stacking new files. Generating clip 2: "
                               "set 2 here and 1 on the Load node. 0 = "
                              "old behaviour, a new numbered file every "
                              "run (numbers count runs, not clips)."}),
                "sample_length": ("INT", {
                    "default": 0, "min": 0, "max": 100000,
                    "tooltip": "Wire Budget.sample_length so the saved "
                               "latent records Director-compatible handoff "
                               "metadata."}),
                "trim_frames": ("INT", {
                    "default": 0, "min": 0, "max": 100000,
                    "tooltip": "Wire Budget.trim_frames (0 for the first "
                               "clip)."}),
                "export_frames": ("INT", {
                    "default": 0, "min": 0, "max": 100000,
                    "tooltip": "Wire Budget.delivered_frames."}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("latent_path",)
    FUNCTION = "save"
    OUTPUT_NODE = True
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = ("Save the sampler's AV latent so the next run's Motion "
                   "Context node can pin audio from it via the matching "
                   "Load node.")

    def save(self, latent, filename_prefix, clip_index=0,
             sample_length=0, trim_frames=0, export_frames=0):
        if _st_save is None:
            raise RuntimeError("h3_motion_context: safetensors is not "
                               "available; cannot save latents.")
        parts = _streams_from_latent(latent)
        if len(parts) < 2:
            raise ValueError(
                "h3_motion_context: latent has no audio stream; wire the "
                "sampler output of an H3 AV graph.")
        video = parts[0].cpu().contiguous()
        audio = parts[1].cpu().contiguous()
        actual_frames = _pixel_frames(int(video.shape[2]))
        if sample_length and int(sample_length) != actual_frames:
            raise ValueError(
                "h3_motion_context: Save Latent received a %d-frame latent "
                "but sample_length is %d. Wire the Budget that produced this "
                "clip's conditioning length." % (actual_frames,
                                                  int(sample_length)))
        if sample_length and export_frames:
            if int(trim_frames) + int(export_frames) > int(sample_length):
                raise ValueError(
                    "h3_motion_context: trim_frames + export_frames (%d) "
                    "exceed sample_length (%d)." %
                    (int(trim_frames) + int(export_frames),
                     int(sample_length)))
        folder, filename, counter, _, _ = folder_paths.get_save_image_path(
            filename_prefix, folder_paths.get_output_directory())
        if int(clip_index) > 0:
            # fixed slot with the natural name: clip 2 -> *_00002. A
            # re-roll of this clip overwrites its own save, so rejects
            # never accumulate or get loaded later. Auto mode (below)
            # keeps a trailing underscore, which is what excludes its
            # run-numbered files from indexed loading.
            path = os.path.join(folder, "%s_%05d.safetensors"
                                % (filename, int(clip_index)))
        else:
            path = os.path.join(folder, "%s_%05d_.safetensors"
                                % (filename, counter))
        metadata = {"format": "h3_motion_context_av_v2"}
        if sample_length and export_frames:
            metadata.update({
                "sample_frames": str(int(sample_length)),
                "trim_frames": str(int(trim_frames)),
                "export_frames": str(int(export_frames)),
            })
        _save_latent_atomic(
            {"video": video, "audio": audio}, path, metadata)
        _LOG.info("h3_motion_context: saved AV latent to %s (video %s, "
                  "audio %s)", path, tuple(video.shape), tuple(audio.shape))
        return (path,)


class MiniMaxH3MotionContextLoadLatent:
    """Load a saved H3 AV latent for the context_latent input.

    clip_index means exactly what it says: set it to the clip you want to
    CONTINUE FROM, and that clip's slot is loaded. Generating clip 2 from
    clip 1: Load node 1, Save node 2. Re-rolling clip 2 changes nothing --
    it reloads slot 1 and overwrites slot 2's reject. Accept, then bump
    both numbers.

    At 0 it loads the newest file in the folder instead. Simple, but NOT
    retry-safe: a re-roll's newest file is the rejected attempt's own
    save, so the retry gets conditioned on the audio you just rejected.

    The output is ONLY for the Motion Context node's context_latent input.
    It is not a decodable latent -- do not wire it into VAE decode.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "latent_path": ("STRING", {
                    "default": "h3_context",
                    "tooltip": "A saved latent file, or a folder (relative "
                               "paths resolve against the ComfyUI output "
                               "directory). Pointing at a specific FILE "
                               "always loads that file, ignoring "
                               "clip_index."}),
                "clip_index": ("INT", {
                    "default": 0, "min": 0, "max": 9999,
                    "tooltip": "The clip to CONTINUE FROM: that clip's "
                               "slot is loaded. Generating clip 2 from "
                               "clip 1: set 1 here and 2 on the Save "
                               "node. 0 = newest file in the folder "
                               "(NOT retry-safe: a re-roll loads its own "
                               "rejected audio)."}),
                "missing_ok": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "Allow a missing previous latent for the "
                               "first clip of a chain. The node returns a "
                               "null latent and context_found=false; wire "
                               "that flag to Budget and Motion Context."}),
            },
            "optional": {
                "current_clip_index": ("INT", {
                    "default": 0, "min": 0, "max": 9999,
                    "tooltip": "The clip being generated now. Exactly 1 is "
                               "an explicit first run: return no latent "
                               "without reading the folder. Values above 1 "
                               "use clip_index normally. Leave 0 for legacy "
                               "graphs."}),
            },
        }

    RETURN_TYPES = ("LATENT", "INT", "STRING", "BOOLEAN")
    RETURN_NAMES = ("latent", "context_end_frame", "latent_path",
                    "context_found")
    FUNCTION = "load"
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = ("Load a latent saved by H3 Motion Context Save Latent, "
                   "for the context_latent input only.")

    @classmethod
    def IS_CHANGED(cls, latent_path, clip_index=0,
                   missing_ok=False, **kwargs):
        # the path string stays constant while the file behind it changes
        # (newest save, or an overwritten slot), so cache on the resolved
        # file identity instead -- otherwise ComfyUI would happily serve
        # a stale latent forever
        current_clip_index = kwargs.get("current_clip_index", 0)
        if int(current_clip_index) == 1:
            return "first-clip"
        try:
            p = _resolve_latent_path(latent_path, clip_index)
            return "%s:%d" % (p, os.stat(p).st_mtime_ns)
        except Exception:
            return float("NaN")  # unresolvable: never cache

    def load(self, latent_path, clip_index=0, missing_ok=False,
             current_clip_index=0):
        if int(current_clip_index) == 1:
            _LOG.info(
                "h3_motion_context: generating clip 1; ignoring previous "
                "latents in %r.", latent_path)
            return (None, 0, "", False)
        if _st_load is None:
            raise RuntimeError("h3_motion_context: safetensors is not "
                               "available; cannot load latents.")
        try:
            path = _resolve_latent_path(latent_path, clip_index)
        except FileNotFoundError:
            if int(current_clip_index) > 1:
                raise RuntimeError(
                    "h3_motion_context: clip %d requires the saved latent for "
                    "clip %d, but it is missing. missing_ok only permits a "
                    "true first run (current_clip_index=1). If this happened "
                    "during a batch, the queue probably ran clips out of "
                    "order or the output folder was changed mid-chain."
                    % (int(current_clip_index), int(clip_index))) from None
            if not missing_ok:
                raise
            _LOG.warning(
                "h3_motion_context: no previous latent at %r; continuing "
                "as the first clip.", latent_path)
            return (None, 0, "", False)
        data = _st_load(path)
        metadata = {}
        if _st_safe_open is not None:
            try:
                with _st_safe_open(path, framework="pt", device="cpu") as f:
                    metadata = f.metadata() or {}
            except Exception as exc:
                _LOG.warning("h3_motion_context: could not read latent "
                             "metadata from %s (%s); using the absolute "
                             "latent tail.", path, exc)
        try:
            context_end = (
                int(metadata.get("trim_frames", 0))
                + int(metadata.get("export_frames", 0))
            )
        except (TypeError, ValueError):
            context_end = 0
        if "video" not in data or "audio" not in data:
            raise ValueError(
                "h3_motion_context: %s is not an h3_motion_context latent "
                "(missing video/audio streams). Was it saved by the stock "
                "Save Latent node instead?" % path)
        _LOG.info("h3_motion_context: loaded AV latent from %s", path)
        # a plain list, not a NestedTensor: only this repo's context_latent
        # input accepts it, which is the point -- it cannot be mistaken
        # for a decodable latent without failing loudly downstream
        return ({"samples": [data["video"], data["audio"]]},
                max(0, context_end), path, True)


class MiniMaxH3MotionContextLatentTaper:
    """Add an in-memory, phase-aligned noise taper to a loaded AV latent.

    This is the latent-space counterpart of Director's pixel-noise T3
    experiment, without the decode/re-encode round trip.  Only the video
    steps Motion Context will select are changed; audio and the saved file
    remain untouched, so one experiment cannot contaminate the next handoff.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "latent": ("LATENT",),
                "context_length": (["22", "5", "39", "56"], {
                    "default": "22",
                    "tooltip": "Must match Motion Context. Only these "
                               "lengths are whole numbers of latent steps."}),
                "strength_rms": ("FLOAT", {
                    "default": 0.01, "min": 0.0, "max": 1.0, "step": 0.001,
                    "tooltip": "Experimental perturbation as a fraction of "
                               "each selected latent step's RMS. This is "
                               "not pixel alpha; 0.01 is the suggested "
                               "identity-protective A/B "
                               "starting point."}),
                "taper_steps": ("INT", {
                    "default": 2, "min": 0, "max": 16,
                    "tooltip": "Perturb only this many EARLY steps, fading "
                               "to zero. Later steps and the final join step "
                               "remain bit-exact to preserve identity."}),
                "seed": ("INT", {
                    "default": 730002, "min": 0, "max": 0xffffffff,
                    "tooltip": "Seed for deterministic latent noise. Noise "
                               "is drawn independently per latent step."}),
                "enabled": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "False passes the latent object through "
                               "unchanged for an exact baseline run."}),
                "strength_curve": ("STRING", {
                    "default": DEFAULT_TAPER_CURVE,
                    "tooltip": "Validated default for a 22-frame context. "
                               "auto derives from strength_rms/taper_steps; "
                               "an explicit list gives one absolute RMS value "
                               "per selected latent step and is zero-padded."}),
            },
            "optional": {
                "context_end_frame": ("INT", {
                    "default": 0, "min": 0, "max": 100000,
                    "tooltip": "Wire Load Latent.context_end_frame. Zero "
                               "uses the same legacy absolute-tail selection "
                               "as Motion Context."}),
                "context_found": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "Wire Load Latent.context_found. False "
                               "passes the null first-run latent through."}),
                "debug_vae": ("VAE", {
                    "tooltip": "Optional video VAE. When wired, decode only "
                               "the selected tapered slice for inspection."}),
            },
        }

    RETURN_TYPES = ("LATENT", "INT", "STRING", "IMAGE")
    RETURN_NAMES = ("latent", "context_end_frame", "report", "debug_images")
    FUNCTION = "apply"
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = ("Experimental Director-style tail softening, performed "
                   "directly on the selected video latent steps. No VAE "
                   "decode/encode in the production path, no pixels, no disk "
                   "mutation, and no audio perturbation. An optional debug "
                   "VAE decodes a side-image only.")

    def apply(self, latent, context_length, strength_rms=0.01,
              taper_steps=2, seed=730002, enabled=True,
              strength_curve=DEFAULT_TAPER_CURVE, context_end_frame=0,
              context_found=True, debug_vae=None):
        if context_found is False:
            debug_images = None
            if debug_vae is not None:
                # Keep a downstream preview valid on the first clip; there is
                # no previous latent to decode yet.
                debug_images = torch.zeros(
                    (1, 64, 64, 3), dtype=torch.float32)
            return (latent, int(context_end_frame),
                    "skipped: context_found=false", debug_images)

        strength = max(0.0, float(strength_rms))
        taper = max(0, int(taper_steps))
        if latent is None:
            raise ValueError(
                "h3_motion_context: Latent Taper has no latent. Wire Load "
                "Latent.latent, or wire context_found=false for the first "
                "clip.")

        parts = _streams_from_latent(latent)
        video = _video_from_latent(latent)
        total_steps = int(video.shape[2])
        configured_frames = _context_frames(context_length)
        available = _pixel_frames(total_steps)
        if context_end_frame:
            available = min(available, max(0, int(context_end_frame)))
        frames = min(configured_frames, available)
        if frames < 1:
            raise ValueError(
                "h3_motion_context: no latent video frames available for "
                "Latent Taper")
        # Match Motion Context's snap-down rule when a handoff is shorter
        # than the configured window.
        frames = next(g for g in VIDEO_RUN_GRID if g <= frames)
        if frames != configured_frames:
            _LOG.warning(
                "h3_motion_context: Latent Taper has %d frames available; "
                "using the %d-frame VAE-grid window to match Motion Context.",
                available, frames)
        selected_steps = _steps_for_frames(frames)
        if selected_steps is None:
            raise ValueError(
                "h3_motion_context: a %d-frame taper window is not a whole "
                "number of latent steps." % frames)

        end = None if not int(context_end_frame) else int(context_end_frame)
        start, pin_end, gap = _phase_aligned_tail_start(
            total_steps, selected_steps, end)

        effective, curve_source = _latent_strength_curve(
            strength_curve, selected_steps, strength, taper)

        out_video = video
        changed = 0
        if enabled and any(value != 0.0 for value in effective):
            generator = torch.Generator(device=getattr(video, "device", None))
            generator.manual_seed(int(seed))
            out_video = video.clone()
            for offset, amount in enumerate(effective):
                if amount == 0.0:
                    continue
                block = video[:, :, start + offset:start + offset + 1]
                rms = torch.sqrt(
                    torch.mean(torch.square(block.float()))).item()
                if rms == 0.0 or not math.isfinite(rms):
                    continue
                noise = torch.randn(
                    block.shape, generator=generator,
                    device=getattr(block, "device", None))
                out_video[:, :, start + offset:start + offset + 1] = (
                    block + (amount / rms) * noise)
                changed += 1

        # Side-channel only: the production latent is never decoded and
        # re-encoded. Decode exactly the selected window Motion Context sees.
        debug_images = None
        if debug_vae is not None:
            debug_samples = out_video[:, :, start:start + selected_steps]
            debug_pixels = debug_vae.decode(debug_samples.contiguous())
            debug_images = _video_vae_images(debug_pixels)

        if not enabled:
            result = latent
            action = "passthrough: disabled, baseline latent unchanged"
        elif changed == 0:
            result = latent
            action = "passthrough: zero-strength baseline latent unchanged"
        else:
            # A plain list is Motion Context's native loaded-latent form. The
            # audio object is intentionally shared: this node never touches it.
            out_parts = list(parts)
            out_parts[0] = out_video
            result = dict(latent)
            result["samples"] = out_parts
            action = "latent taper"

        report = (
            "%s: steps %d-%d/%d, pin end %df, gap %df; curve %s; "
            "strengths %s; changed %d steps; audio and disk latent unchanged"
            % (action, start, start + selected_steps - 1, total_steps,
               pin_end, gap, curve_source,
               ",".join("%.4g" % x for x in effective), changed))
        return (result, int(context_end_frame), report, debug_images)


class MiniMaxH3MotionContextUpdateHandoff:
    """Persist a phase-alignment trim in a saved latent's handoff."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "latent_path": ("STRING", {
                    "tooltip": "Wire Load Latent.latent_path for the "
                               "previous clip."}),
                "trim_frames": ("INT", {
                    "default": 0, "min": 0, "max": 100000,
                    "tooltip": "Wire Motion Context.trim_previous_export."}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("latent_path",)
    FUNCTION = "update"
    OUTPUT_NODE = True
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = ("Match Director cache behavior after phase-aligning: when "
                   "the previous export loses tail frames, decrement that "
                   "clip's saved export_frames so the next handoff uses the "
                   "real concatenated timeline end.")

    def update(self, latent_path, trim_frames):
        removed = 0 if trim_frames is None else max(0, int(trim_frames))
        if removed == 0:
            # First-clip graphs keep this output node active while the Load
            # Latent branch is bypassed; with nothing to trim there is no
            # handoff to read or rewrite.
            return ("" if latent_path is None else latent_path,)
        if _st_load is None or _st_save is None or _st_safe_open is None:
            raise RuntimeError(
                "h3_motion_context: safetensors is unavailable; cannot update "
                "latent handoff metadata.")
        path = latent_path
        if not os.path.isfile(path):
            path = _resolve_latent_path(path)
        with _st_safe_open(path, framework="pt", device="cpu") as f:
            metadata = dict(f.metadata() or {})
        if not all(k in metadata for k in
                   ("trim_frames", "export_frames")):
            raise ValueError(
                "h3_motion_context: %s has no Director handoff metadata. "
                "Re-save it with Budget sample/trim/export wired." % path)
        old_export = int(metadata["export_frames"])
        if removed >= old_export:
            raise ValueError(
                "h3_motion_context: cannot remove %d frames from a %d-frame "
                "handoff export." % (removed, old_export))
        if removed == 0:
            return (path,)
        metadata["export_frames"] = str(old_export - removed)
        tensors = _st_load(path)
        _save_latent_atomic(tensors, path, metadata)
        _LOG.info("h3_motion_context: updated handoff in %s: export %d -> %d",
                  path, old_export, old_export - removed)
        return (path,)


NODE_CLASS_MAPPINGS = {
    "MiniMaxH3MotionContext": MiniMaxH3MotionContext,
    "MiniMaxH3MotionContextTrim": MiniMaxH3MotionContextTrim,
    "MiniMaxH3MotionContextTrimExportTail": MiniMaxH3MotionContextTrimExportTail,
    "MiniMaxH3MotionContextBudget": MiniMaxH3MotionContextBudget,
    "MiniMaxH3MotionContextSaveLatent": MiniMaxH3MotionContextSaveLatent,
    "MiniMaxH3MotionContextLoadLatent": MiniMaxH3MotionContextLoadLatent,
    "MiniMaxH3MotionContextLatentTaper": MiniMaxH3MotionContextLatentTaper,
    "MiniMaxH3MotionContextUpdateHandoff": MiniMaxH3MotionContextUpdateHandoff,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "MiniMaxH3MotionContext": "H3 Motion Context",
    "MiniMaxH3MotionContextTrim": "H3 Motion Context Trim",
    "MiniMaxH3MotionContextTrimExportTail": "H3 Motion Context Trim Export Tail",
    "MiniMaxH3MotionContextBudget": "H3 Motion Context Budget",
    "MiniMaxH3MotionContextSaveLatent": "H3 Motion Context Save Latent",
    "MiniMaxH3MotionContextLoadLatent": "H3 Motion Context Load Latent",
    "MiniMaxH3MotionContextLatentTaper":
        "H3 Motion Context Latent Taper",
    "MiniMaxH3MotionContextUpdateHandoff": "H3 Motion Context Update Handoff",
}
