"""Smoke test: run MiniMaxH3MotionContext.apply() end to end with fakes.

Fakes ComfyUI's modules and tensor ops (numpy-backed) and drives the node
exactly as a graph would: a 124-frame clip at 480x864, 22 context frames,
audio from the previous clip's LATENT. Checks the produced conditioning
values: keyframe count and indices, the audio ref's step count, and the
fractional end_frame carrying the grid-overhang compensation.
"""

import sys
import types

import numpy as np

import os
_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
_PKG_DIR = os.path.dirname(_TESTS_DIR)  # repo root, where the package lives
sys.path.insert(0, _TESTS_DIR)
from _mock_harness import make_mm, make_torch  # noqa: E402


class T:
    """Minimal numpy-backed tensor stand-in."""

    def __init__(self, a):
        self.a = np.asarray(a)

    @property
    def shape(self):
        return self.a.shape

    @property
    def ndim(self):
        return self.a.ndim

    def __getitem__(self, idx):
        return T(self.a[idx])

    def __setitem__(self, idx, value):
        self.a[idx] = value.a if isinstance(value, T) else value

    def __add__(self, other):
        return T(self.a + (other.a if isinstance(other, T) else other))

    def __sub__(self, other):
        return T(self.a - (other.a if isinstance(other, T) else other))

    def __mul__(self, other):
        return T(self.a * (other.a if isinstance(other, T) else other))

    def __rmul__(self, other):
        return self.__mul__(other)

    def float(self):
        return T(self.a.astype(np.float32))

    def movedim(self, src, dst):
        return T(np.moveaxis(self.a, src, dst))

    def unsqueeze(self, d):
        return T(np.expand_dims(self.a, d))

    def clone(self):
        return T(self.a.copy())

    def cpu(self):
        return self

    @property
    def device(self):
        return None

    def contiguous(self):
        return T(np.ascontiguousarray(self.a))

    def reshape(self, *shape):
        if len(shape) == 1 and isinstance(shape[0], tuple):
            shape = shape[0]
        return T(self.a.reshape(shape))


class Nested:
    def __init__(self, parts):
        self.parts = parts

    def unbind(self):
        return list(self.parts)


def main():
    # fake modules the package imports
    mm = make_mm()
    for name in ("comfy", "comfy.ldm", "comfy.ldm.minimax"):
        sys.modules.setdefault(name, types.ModuleType(name))
    sys.modules["comfy.ldm.minimax.model"] = mm
    sys.modules["comfy"].ldm = sys.modules["comfy.ldm"]
    sys.modules["comfy.ldm"].minimax = sys.modules["comfy.ldm.minimax"]
    sys.modules["comfy.ldm.minimax"].model = mm
    sys.modules["torch"] = make_torch()

    cu = types.ModuleType("comfy.utils")
    cu.common_upscale = lambda s, w, h, m, c: T(
        np.zeros((s.shape[0], 3, h, w), dtype=np.float32))
    sys.modules["comfy.utils"] = cu
    sys.modules["comfy"].utils = cu

    mb = types.ModuleType("comfy.model_base")

    class MiniMaxH3:
        def extra_conds(self, **kw):
            return {}
    mb.MiniMaxH3 = MiniMaxH3
    sys.modules["comfy.model_base"] = mb
    sys.modules["comfy"].model_base = mb

    captured = {}
    nh = types.ModuleType("node_helpers")

    def conditioning_set_values(cond, values, append=False):
        # faithful to ComfyUI's node_helpers: copy each entry's dict, and
        # when appending, concatenate onto whatever is already under the
        # key instead of replacing it. The append path is what lets a
        # Ref2VA graph keep its own reference blocks.
        out = []
        for t in cond:
            n = [t[0], t[1].copy()]
            for k, v in values.items():
                if append:
                    old = n[1].get(k, None)
                    if old is not None:
                        v = old + v
                n[1][k] = v
            out.append(n)
        captured.clear()
        captured.update(out[0][1])
        return out
    nh.conditioning_set_values = conditioning_set_values
    sys.modules["node_helpers"] = nh

    import os
    import tempfile
    outdir = tempfile.mkdtemp()
    fp = types.ModuleType("folder_paths")
    fp.get_output_directory = lambda: outdir

    def get_save_image_path(prefix, out, *a):
        sub, name = os.path.split(prefix)
        folder = os.path.join(out, sub)
        os.makedirs(folder, exist_ok=True)
        counter = 1 + sum(1 for f in os.listdir(folder)
                          if f.startswith(name))
        return folder, name, counter, sub, prefix
    fp.get_save_image_path = get_save_image_path
    sys.modules["folder_paths"] = fp

    st = types.ModuleType("safetensors")
    stt = types.ModuleType("safetensors.torch")

    def save_file(d, path, metadata=None):
        assert path.endswith(".part"), path
        np.savez(path + ".npz", **{k: v.a for k, v in d.items()})
        open(path, "w").write(path + ".npz")
        if metadata:
            import json
            with open(path + ".meta", "w") as f:
                json.dump(metadata, f)

    def load_file(path):
        real = open(path).read()
        z = np.load(real)
        return {k: T(z[k]) for k in z.files}

    class safe_open:
        def __init__(self, path, framework="pt", device="cpu"):
            self.path = path

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def metadata(self):
            import json
            if not os.path.exists(self.path + ".meta"):
                # Atomic-save fake: the moved placeholder points at the
                # temporary file that still holds its .npz/.meta sidecars.
                data_file = open(self.path).read()
                meta_file = data_file[:-4] + ".meta"
                if not os.path.exists(meta_file):
                    return {}
                with open(meta_file) as f:
                    return json.load(f)
            with open(self.path + ".meta") as f:
                return json.load(f)

    st.safe_open = safe_open
    stt.save_file, stt.load_file = save_file, load_file
    st.torch = stt
    sys.modules["safetensors"] = st
    sys.modules["safetensors.torch"] = stt

    # import the package by file location so it works whatever the repo
    # folder is called (ComfyUI-H3-Motion-Context, h3_motion_context, ...)
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "h3mc_pkg", os.path.join(_PKG_DIR, "__init__.py"),
        submodule_search_locations=[_PKG_DIR])
    pkg = importlib.util.module_from_spec(spec)
    sys.modules["h3mc_pkg"] = pkg
    spec.loader.exec_module(pkg)  # registers nodes; patches apply on first run
    nodes = sys.modules["h3mc_pkg.nodes"]
    assert pkg.NODE_CLASS_MAPPINGS
    # importing the pack must not have touched ComfyUI yet
    assert not nodes._layout_patch_applied(), \
        "the layout patch was applied at import time"
    assert not nodes._payload_patch_applied(), \
        "the payload patch was applied at import time"
    assert mm.PackedLayout.__init__.__name__ != "_patched_init", \
        "the constructor was wrapped at import time"

    # a 124-frame clip: latent_t 37 (7 full 17-frame groups + 1 + 4),
    # audio grid ceil(124 * 5/3) = 207 steps, overhang exactly 1/3
    latent_t, frames, audio_t = 37, 124, 207
    assert nodes._pixel_frames(latent_t) == frames
    h, w = 480 // 16, 864 // 16
    target = {"samples": Nested([
        T(np.zeros((1, 16, latent_t, h, w), dtype=np.float32)),
        T(np.zeros((1, 32, 2, audio_t), dtype=np.float32)),
    ])}
    # previous clip's sampler latent (same dims in this setup)
    prev = {"samples": Nested([
        T(np.arange(1 * 16 * latent_t * h * w, dtype=np.float32
                    ).reshape(1, 16, latent_t, h, w)),
        T(np.arange(1 * 32 * 2 * audio_t, dtype=np.float32
                    ).reshape(1, 32, 2, audio_t)),
    ])}
    context = T(np.zeros((124, 480, 864, 3), dtype=np.float32))

    class VAE:
        def encode(self, x):
            n = x.shape[0]
            steps = max(1, (n - 5) // 17 * 5 + 2)
            return T(np.zeros((1, 16, steps, h, w), dtype=np.float32))

    class DebugVAE:
        calls = []

        def decode(self, samples):
            DebugVAE.calls.append(samples)
            return T(np.zeros(
                (1, samples.shape[2], 4, 4, 3), dtype=np.float32))

    node = nodes.MiniMaxH3MotionContext()
    # Video-only context still needs the payload patch: a Ref2VA graph can
    # carry image references alongside these keyframes, and stock would let
    # those references replace the keyframe latents.
    node.apply(
        conditioning=[["c", {}]], vae=VAE(), latent=target,
        context_length="22", audio_context_length=24,
        context_latent=prev, audio_context_enabled=False)
    assert nodes._payload_patch_applied()
    captured.clear()

    out, trim, prev_export_trim = node.apply(
        conditioning=[["c", {}]], vae=VAE(), latent=target,
        context_frames=context, context_length="22",
        audio_context_length=22, context_latent=prev)

    # ... and running one must have installed both
    assert nodes._layout_patch_applied() and nodes._payload_patch_applied()
    assert mm.PackedLayout.__init__.__name__ == "_patched_init"

    kfs = captured["minimax_keyframes"]
    assert len(kfs) == 7, len(kfs)
    idx = [kf[nodes.MC_KEY] for kf in kfs]
    assert idx == [0, 1, 5, 9, 13, 17, 18], idx
    assert captured["minimax_frame_count"] == frames
    assert trim == 22

    ref = captured["minimax_refs"][0]
    assert ref["kind"] == "audio"
    assert ref["ref_audio_t"] == 37, ref["ref_audio_t"]  # round(22/24*40)
    tail = ref["audio_latent"]
    assert tuple(tail.shape) == (1, 32, 2, 37), tail.shape
    # tail must be the LAST 37 steps of the source
    assert float(tail.a[0, 0, 0, -1]) == float(prev["samples"].parts[1]
                                               .a[0, 0, 0, -1])
    # the window must land on the target's own integer audio grid: the
    # end coordinate is FRAME_RESCALE * end_frame and the target's audio
    # rows sit on integers, so a fractional end coordinate would place
    # the pinned content between them (a third of a step is 8.3 ms)
    got_end = ref[nodes.MC_AUDIO_KEY]
    end_coord = nodes.FRAME_RESCALE * got_end
    assert abs(end_coord - round(end_coord)) < 1e-9, end_coord
    assert abs(end_coord - 37.0) < 1e-9, end_coord
    assert abs(got_end - 22.2) < 1e-6, got_end
    # the pinned VIDEO must have come out of the latent too, not the VAE.
    # The fake VAE returns zeros, so any nonzero block proves the source,
    # and each block must equal the matching step of the source latent.
    kf_blocks = [kf["latent"] for kf in kfs]
    src = prev["samples"].parts[0].a
    start = latent_t - len(kf_blocks)          # 37 - 7 = 30, cycle pos 0
    assert start % 5 == 0, start
    for k, blk in enumerate(kf_blocks):
        assert tuple(blk.shape) == (1, 16, 1, h, w), blk.shape
        assert np.array_equal(blk.a[0, :, 0], src[0, :, start + k]), k
    assert nodes._steps_for_frames(22) == 7
    assert nodes._steps_for_frames(5) == 2
    assert nodes._steps_for_frames(39) == 12
    assert nodes._steps_for_frames(1) == 1
    assert nodes._steps_for_frames(3) is None    # not a whole step boundary
    print("latent path: 7 cond blocks at %s sliced from the latent tail "
          "(bit-identical to the source steps), audio 37 steps, end_frame "
          "%.4f (overhang-compensated)" % (idx, got_end))

    # video-only latent context: the switch keeps the exact video blocks but
    # emits no motion-context audio reference at all
    captured.clear()
    node.apply(
        conditioning=[["c", {}]], vae=VAE(), latent=target,
        context_length="22", audio_context_length=24,
        context_latent=prev, audio_context_enabled=False)
    video_only_kfs = captured["minimax_keyframes"]
    assert [kf[nodes.MC_KEY] for kf in video_only_kfs] == idx
    assert captured.get("minimax_refs") is None
    for got, src_step in zip(video_only_kfs, range(30, 37)):
        assert np.array_equal(
            got["latent"].a[0, :, 0], prev["samples"].parts[0].a[0, :, src_step])
    print("video-only latent path: exact video blocks retained, no audio ref")

    # no latent wired: the pixel path, same offsets, and the fake VAE
    # returns zeros so the blocks must now be zero rather than sliced.
    # No audio either, so node_helpers is never called: read the
    # conditioning the node returns rather than the capture hook
    res, _, _ = node.apply(
        conditioning=[["c", {}]], vae=VAE(), latent=target,
        context_frames=context, context_length="22",
        audio_context_length=22)
    px = res[0][1]["minimax_keyframes"]
    assert [kf[nodes.MC_KEY] for kf in px] == idx, "offsets differ by source"
    assert float(px[0]["latent"].a.max()) == 0.0, "did not use the VAE"
    print("pixels path: same %d blocks at the same offsets, encoded rather "
          "than sliced" % len(px))

    # a resolution change cannot slice a latent and must refuse, not
    # quietly take the lossy path
    small = {"samples": Nested([
        T(np.zeros((1, 16, latent_t, h // 2, w // 2), dtype=np.float32)),
        T(np.zeros((1, 32, 2, audio_t), dtype=np.float32)),
    ])}
    try:
        node.apply(
            conditioning=[["c", {}]], vae=VAE(), latent=target,
            context_frames=context, context_length="22",
            audio_context_length=22, context_latent=small)
    except ValueError as e:
        assert "cannot be resized" in str(e), str(e)
        print("resolution change: refused, with the reason and the two "
              "resolutions named")
    else:
        raise AssertionError("mismatched latent did not refuse")

    # nothing wired at all
    try:
        node.apply(
            conditioning=[["c", {}]], vae=VAE(), latent=target,
            context_length="22", audio_context_length=22)
    except ValueError as e:
        assert "nothing to pin" in str(e), str(e)
        print("nothing wired: refused with a plain reason")
    else:
        raise AssertionError("no context at all did not refuse")

    # the constants that replaced the widgets must be on the good values
    assert nodes.ENCODE_MODE == "video"
    assert nodes.ANCHOR_MODE == "head"
    assert nodes.AUDIO_MODE == "timeline"
    assert nodes.CROP == "disabled"

    # Director duration budget: align the visible/export length first, then
    # align visible+context for sampling. Decode trims the pinned head and
    # crops the sample-grid overshoot back to the exact visible length.
    budget = nodes.MiniMaxH3MotionContextBudget()
    for desired, ctx, want_sample, want_delivered, want_added in (
            (120, 22, 158, 124, 4),
            (124, 22, 158, 124, 0),
            (72, 22, 107, 73, 1),
            (120, 0, 124, 124, 4)):
        got = budget.budget(desired, str(ctx))
        assert got == (want_sample, ctx, want_delivered, want_added), (
            desired, ctx, got)
        assert got[0] % 17 == 5
        assert got[2] >= desired
    assert budget.budget(240, "22", context_available=False) == \
        (243, 0, 243, 3)
    for desired, ctx, want in (
            (198, 22, (226, 22, 204, 6)),
            (124, 22, (158, 22, 136, 12)),
            (120, 0, (124, 0, 124, 4))):
        got = budget.budget(desired, str(ctx), preserve_tail=True)
        assert got == want, (desired, got)
        assert got[0] % 17 == 5
        assert got[2] == got[0] - got[1]
        assert got[2] >= desired
    assert budget.budget(
        240, "22", context_available=False, preserve_tail=True) == \
        (243, 0, 243, 3)
    assert "MiniMaxH3MotionContextBudget" in nodes.NODE_CLASS_MAPPINGS
    print("budget check: desired -> aligned export, sample = align(export+"
          "context), export is exact after decode crop")
    print("preserve-tail budget: sample overshoot stays in the export")

    # the cycle-position property the whole latent video path rests on,
    # checked across every clip length and window rather than argued for
    for g in range(1, 40):
        steps_total = 5 * g + 2
        frames_total = nodes._pixel_frames(steps_total)
        assert (frames_total - 5) % 17 == 0, (g, frames_total)
        for wnd in (5, 22, 39, 56):
            st = nodes._steps_for_frames(wnd)
            if st is None or st > steps_total:
                continue
            begin = steps_total - st
            assert begin % 5 == 0, (frames_total, wnd, begin % 5)
            assert nodes._pixel_frames(st) == wnd
            # offsets computed for a fresh run must match the sliced run
            assert (nodes._step_offsets(st)
                    == [nodes._pixel_frames(k) for k in range(st)])
    print("cycle check: every clip length 22..%d x windows 5/22/39/56 "
          "slices from cycle position 0" % nodes._pixel_frames(5 * 39 + 2))

    # decoded-audio path must still work and carry integer end_frame
    captured.clear()

    class AudioVAE:
        audio_sample_rate = 32000

        def encode(self, x):
            steps = int(round(x.shape[-2] / 32000 * 40))
            return T(np.zeros((1, 32, 2, steps), dtype=np.float32))

    audio = {"waveform": T(np.zeros((1, 2, 32000), dtype=np.float32)),
             "sample_rate": 32000}
    node.apply(
        conditioning=[["c", {}]], vae=VAE(), latent=target,
        context_frames=context, context_length="22",
        audio_context_length=22, audio_vae=AudioVAE(), context_audio=audio)
    ref2 = captured["minimax_refs"][0]
    # no overhang to compensate on this path, but the same grid rule
    # applies: 22 frames is 36.667 steps, which must snap to 37
    end2 = nodes.FRAME_RESCALE * ref2[nodes.MC_AUDIO_KEY]
    assert abs(end2 - 37.0) < 1e-9, end2
    print("vae path: window snapped to the audio grid, end coord %.1f" % end2)

    # every clip length on the ladder, every window, both paths: the
    # pinned window must always end on an integer audio coordinate
    for g in range(2, 13):
        f = 17 * g + 5
        # nearest, not ceil: ceil would simulate +2/3 on the lengths that
        # actually run -1/3, so this loop used to exercise a value the
        # model never produces
        at = round(nodes.FRAME_RESCALE * f)
        oh = at - nodes.FRAME_RESCALE * f
        for span in (5, 22, 39, 56):
            for ohv in (0.0, oh):
                ef = span + ohv / nodes.FRAME_RESCALE
                ec = round(nodes.FRAME_RESCALE * ef)
                ef = ec / nodes.FRAME_RESCALE
                c = nodes.FRAME_RESCALE * ef
                assert abs(c - round(c)) < 1e-9, (f, span, ohv, c)
    print("grid check: every ladder length x window 5/22/39/56 x both "
          "audio paths ends on an integer audio coordinate")

    # All three frame-count residues, latent path, 22-frame window. The
    # 124-frame case above is frames % 3 == 1, the one residue where
    # rounding up and rounding to nearest agree, so on its own it cannot
    # tell the two rules apart. 260 frames is the negative-overhang case:
    # compensation moves the end coordinate to 36.33, which rounds to 36,
    # where failing open would leave it at 36.67 and round to 37, a whole
    # audio step (25 ms) late.
    import logging as _logging

    class _Catcher(_logging.Handler):
        def __init__(self):
            _logging.Handler.__init__(self)
            self.msgs = []

        def emit(self, record):
            self.msgs.append(record.getMessage())

    catcher = _Catcher()
    catcher.setLevel(_logging.WARNING)
    nodes._LOG.addHandler(catcher)
    try:
        for lt, f, at, want_coord, want_end in (
                (37, 124, 207, 37, 22.2),   # +1/3, reaches past
                (72, 243, 405, 37, 22.2),   #    0, exact
                (77, 260, 433, 37, 22.2)):  # -1/3: Director assumes 0
            assert nodes._pixel_frames(lt) == f, (lt, f)
            assert at == round(nodes.FRAME_RESCALE * f), (f, at)
            captured.clear()
            del catcher.msgs[:]
            tgt = {"samples": Nested([
                T(np.zeros((1, 16, lt, h, w), dtype=np.float32)),
                T(np.zeros((1, 32, 2, at), dtype=np.float32)),
            ])}
            src = {"samples": Nested([
                T(np.arange(1 * 16 * lt * h * w, dtype=np.float32
                            ).reshape(1, 16, lt, h, w)),
                T(np.arange(1 * 32 * 2 * at, dtype=np.float32
                            ).reshape(1, 32, 2, at)),
            ])}
            node.apply(
                conditioning=[["c", {}]], vae=VAE(), latent=tgt,
                context_frames=T(np.zeros((f, 480, 864, 3),
                                          dtype=np.float32)),
                context_length="22", audio_context_length=22,
                context_latent=src)
            got = captured["minimax_refs"][0][nodes.MC_AUDIO_KEY]
            coord = nodes.FRAME_RESCALE * got
            assert abs(coord - round(coord)) < 1e-9, (f, coord)
            assert abs(coord - want_coord) < 1e-9, (f, coord, want_coord)
            assert abs(got - want_end) < 1e-6, (f, got, want_end)
            # The negative-overhang residue intentionally warns and assumes
            # zero, matching Director's export-end handoff behavior.
    finally:
        nodes._LOG.removeHandler(catcher)
    print("residue check: frames % 3 in 0/1/2 accepted; all use the "
          "Director end coordinate 37")

    # The trim node matches Director: a long tail is truncated and a short
    # one is left unpadded, because the handoff is based on frame count.
    trimmer = nodes.MiniMaxH3MotionContextTrim()
    for f, direction in ((124, "long"), (243, "exact"), (260, "short")):
        sr = 32000
        # what H3 actually ships: the audio grid at nearest rounding,
        # decoded back to samples
        steps = round(nodes.FRAME_RESCALE * f)
        have = int(round(steps / nodes.AUDIO_HZ * sr))
        want = min(
            have - int(round((22 / 24.0) * sr)),
            int(round((f - 22) / 24.0 * sr)),
        )
        imgs = T(np.zeros((f, 8, 8, 3), dtype=np.float32))
        wav = T(np.zeros((1, 2, have), dtype=np.float32))
        _, out = trimmer.trim(
            images=imgs, trim_frames=22,
            audio={"waveform": wav, "sample_rate": sr}, fps=24.0,
            match_tail=True)
        got = int(out["waveform"].shape[-1])
        assert got == want, (f, direction, got, want)
        assert got == want, (f, direction, got, want)
    print("match_tail check: long tail trimmed, short tail left unpadded")

    # Ref2VA: a graph whose conditioning already carries reference blocks
    # must keep every one of them, with the motion context audio block
    # appended rather than replacing the lot. Before this, the node
    # assigned minimax_refs outright and an R2V graph silently lost its
    # references at the moment chaining was switched on.
    captured.clear()
    existing = [
        {"kind": "image", "latent_h": 8, "latent_w": 12},
        {"kind": "video_audio", "latent_h": 8, "latent_w": 12,
         "latent_t": 3, "ref_audio_t": 5},
        {"kind": "audio", "ref_audio_t": 9},
    ]
    r2v_cond = [["c", {"minimax_refs": [dict(r) for r in existing]}]]
    out_cond, _, _ = node.apply(
        conditioning=r2v_cond, vae=VAE(), latent=target,
        context_frames=context, context_length="22",
        audio_context_length=22, context_latent=prev)
    refs_out = captured["minimax_refs"]
    assert len(refs_out) == 4, len(refs_out)
    for got, want in zip(refs_out, existing):
        assert got["kind"] == want["kind"], (got, want)
        assert got.get(nodes.MC_AUDIO_KEY) is None, got
    assert refs_out[-1][nodes.MC_AUDIO_KEY] is not None
    assert refs_out[-1]["ref_audio_t"] == 37
    # the caller's own list must not have been mutated in place
    assert len(r2v_cond[0][1]["minimax_refs"]) == 3
    assert captured["minimax_keyframes"], "keyframes lost on the R2V path"
    print("R2V path: 3 incoming references preserved, motion context audio "
          "appended as the 4th, keyframes intact")

    # last_frame passthrough: an fl2va graph's own anchors used to be
    # replaced outright. The last-frame anchor must survive, tagged with
    # MC_KEY so the layout patch compensates it alongside ours; the
    # first-frame anchor sits inside the pinned head, which the pinned
    # run already decides, so it is dropped with a warning.
    captured.clear()
    up_kf = [{"resolved_frame_index": 0, "latent": "FF"},
             {"resolved_frame_index": frames - 1, "latent": "LF"}]
    fl_cond = [["c", {"minimax_keyframes": [dict(k) for k in up_kf],
                      "minimax_frame_count": frames}]]
    catcher2 = _Catcher()
    nodes._LOG.addHandler(catcher2)
    try:
        node.apply(
            conditioning=fl_cond, vae=VAE(), latent=target,
            context_frames=context, context_length="22",
            audio_context_length=22, context_latent=prev)
    finally:
        nodes._LOG.removeHandler(catcher2)
    merged = captured["minimax_keyframes"]
    assert len(merged) == 1 + 7, len(merged)
    assert [kf[nodes.MC_KEY] for kf in merged[:-1]] == idx
    assert merged[-1]["latent"] == "LF"
    assert merged[-1][nodes.MC_KEY] == frames - 1
    assert merged[-1]["resolved_frame_index"] == frames - 1
    assert any("dropped 1 keyframe anchor" in m for m in catcher2.msgs), \
        catcher2.msgs
    # the caller's dicts must not have been tagged in place
    assert nodes.MC_KEY not in fl_cond[0][1]["minimax_keyframes"][1]
    # keyframes resolved against a different clip length are a wiring
    # error: the anchor would land at the wrong frame, so refuse
    bad_cond = [["c", {"minimax_keyframes": [dict(up_kf[1])],
                       "minimax_frame_count": frames + 17}]]
    try:
        node.apply(conditioning=bad_cond, vae=VAE(), latent=target,
                   context_frames=context, context_length="22",
                   audio_context_length=22, context_latent=prev)
    except ValueError as e:
        assert "resolved for a" in str(e), str(e)
    else:
        raise AssertionError("frame-count mismatch did not refuse")
    print("last_frame path: context rows precede the upstream last-frame "
          "anchor, first-frame anchor dropped from the pinned head, "
          "frame-count mismatch refused")

    first_cond = [["first", {}]]
    first_out, first_trim, first_prev_trim = node.apply(
        conditioning=first_cond, vae=VAE(), latent=target,
        context_length="22", audio_context_length=24,
        context_latent=None, context_found=False)
    assert first_out is first_cond
    assert (first_trim, first_prev_trim) == (0, 0)
    print("first-run path: missing latent passes conditioning through with "
          "no pinned head")

    # Experimental latent taper: Director's pixel T3 idea without a VAE
    # round trip. Disabled/zero-strength are exact baselines, while the
    # enabled path changes only Motion Context's selected video steps.
    taper = nodes.MiniMaxH3MotionContextLatentTaper()
    disabled, disabled_end, disabled_report, disabled_debug = taper.apply(
        prev, "22", enabled=False)
    assert disabled is prev and disabled_end == 0
    assert "baseline" in disabled_report
    assert disabled_debug is None
    zero, _, zero_report, _ = taper.apply(
        prev, "22", strength_rms=0.0, strength_curve="auto")
    assert zero is prev and "baseline" in zero_report
    missing, missing_end, missing_report, missing_debug = taper.apply(
        None, "22", context_end_frame=17, context_found=False)
    assert missing is None and missing_end == 17
    assert missing_report == "skipped: context_found=false"
    assert missing_debug is None
    before_first_debug_call = len(DebugVAE.calls)
    _, _, first_debug_report, first_debug_images = taper.apply(
        None, "22", context_end_frame=17, context_found=False,
        debug_vae=DebugVAE())
    assert len(DebugVAE.calls) == before_first_debug_call
    assert first_debug_images.shape == (1, 64, 64, 3)
    assert first_debug_report == "skipped: context_found=false"

    taper_src = {"samples": Nested([
        T(np.sin(np.arange(1 * 16 * latent_t * h * w, dtype=np.float32)
                 * 0.007).reshape(1, 16, latent_t, h, w)),
        T(np.zeros((1, 32, 2, audio_t), dtype=np.float32)),
    ])}
    original_video = taper_src["samples"].parts[0].a.copy()
    original_audio = taper_src["samples"].parts[1].a.copy()
    tapered, tapered_end, taper_report, tapered_debug = taper.apply(
        taper_src, "22", strength_rms=0.01, taper_steps=2,
        strength_curve="auto", seed=730002)
    tapered_video = tapered["samples"][0].a
    assert tapered_end == 0
    assert tapered["samples"][1] is taper_src["samples"].parts[1]
    assert np.array_equal(original_audio, taper_src["samples"].parts[1].a)
    assert np.array_equal(original_video, taper_src["samples"].parts[0].a)
    assert np.array_equal(tapered_video[:, :, :30],
                          original_video[:, :, :30])
    for step in (30, 31):
        assert not np.array_equal(tapered_video[:, :, step],
                                  original_video[:, :, step]), step
    for step in range(32, 37):
        assert np.array_equal(tapered_video[:, :, step],
                              original_video[:, :, step]), step
    assert "steps 30-36/37" in taper_report
    assert "0.01,0.005,0,0,0,0,0" in taper_report
    assert "curve auto" in taper_report
    assert "audio and disk latent unchanged" in taper_report
    assert tapered_debug is None

    again, _, _, _ = taper.apply(
        taper_src, "22", strength_rms=0.01, taper_steps=2,
        strength_curve="auto", seed=730002)
    assert np.array_equal(again["samples"][0].a, tapered_video)
    other, _, _, _ = taper.apply(
        taper_src, "22", strength_rms=0.01, taper_steps=2,
        strength_curve="auto", seed=730003)
    assert not np.array_equal(other["samples"][0].a, tapered_video)

    explicit_text = "0.24, 0.24, 0.24, 0.24, 0.24, 0.12, 0"
    default_curved, _, default_report, _ = taper.apply(
        taper_src, "22", strength_rms=0.01, taper_steps=2, seed=730002)
    assert "curve explicit" in default_report
    assert "0.24,0.24,0.24,0.24,0.24,0.12,0" in default_report
    curved, curved_end, curved_report, _ = taper.apply(
        taper_src, "22", strength_rms=0.01, taper_steps=2,
        strength_curve=explicit_text, seed=730002)
    curved_video = curved["samples"][0].a
    assert curved_end == 0
    assert "curve explicit" in curved_report
    assert "0.24,0.24,0.24,0.24,0.24,0.12,0" in curved_report
    for step in range(30, 36):
        assert not np.array_equal(curved_video[:, :, step],
                                  original_video[:, :, step]), step
    assert np.array_equal(curved_video[:, :, 36],
                          original_video[:, :, 36])

    short, _, short_report, _ = taper.apply(
        taper_src, "22", strength_curve="0.08,0.08", seed=730002)
    assert np.array_equal(short["samples"][0].a[:, :, 32:],
                          original_video[:, :, 32:])
    assert "0.08,0.08,0,0,0,0,0" in short_report

    for bad in ("-0.01,0", "nope,0", "nan,0", "0,0,0,0,0,0,0,0"):
        try:
            taper.apply(taper_src, "22", strength_curve=bad)
        except ValueError:
            pass
        else:
            raise AssertionError("bad curve accepted: %r" % bad)

    before_debug_calls = len(DebugVAE.calls)
    debug_out, _, debug_report, debug_images = taper.apply(
        taper_src, "22", strength_curve=explicit_text, seed=730002,
        debug_vae=DebugVAE())
    assert len(DebugVAE.calls) == before_debug_calls + 1
    decoded = DebugVAE.calls[-1]
    assert tuple(decoded.shape) == (1, 16, 7, h, w)
    assert np.array_equal(decoded.a, debug_out["samples"][0].a[:, :, 30:37])
    assert debug_images.shape[0] == 7
    assert debug_images.shape[1:] == (4, 4, 3)
    assert "debug" not in debug_report  # latent report stays production-only

    phase_src = {"samples": Nested([
        T(np.arange(16 * 47 * h * w, dtype=np.float32
                    ).reshape(1, 16, 47, h, w)),
        T(np.zeros((1, 32, 2, 79), dtype=np.float32)),
    ])}
    phase_out, phase_end, phase_report, _ = taper.apply(
        phase_src, "22", context_end_frame=146, seed=730002)
    assert phase_end == 146
    assert "steps 35-41/47" in phase_report
    assert "pin end 141f, gap 5f" in phase_report
    assert np.array_equal(phase_out["samples"][0].a[:, :, :35],
                          phase_src["samples"].parts[0].a[:, :, :35])
    assert np.array_equal(phase_out["samples"][0].a[:, :, 42:],
                          phase_src["samples"].parts[0].a[:, :, 42:])
    assert np.array_equal(phase_out["samples"][0].a[:, :, 41],
                          phase_src["samples"].parts[0].a[:, :, 41])
    assert ("MiniMaxH3MotionContextLatentTaper"
            in nodes.NODE_CLASS_MAPPINGS)
    print("latent taper: only selected phase-aligned video steps changed; "
          "last step exact, audio shared, baseline reversible")

    # save -> load -> context_latent roundtrip across "runs"
    import time
    saver = nodes.MiniMaxH3MotionContextSaveLatent()
    loader = nodes.MiniMaxH3MotionContextLoadLatent()

    # Director handoff metadata and phase alignment: a 124f export sampled
    # as 158f with a 22f pinned head ends at sample frame 146. The nearest
    # legal 7-step pin ends at 141, so the previous export loses 5f.
    prev_t, prev_frames, prev_audio_t = 47, 158, 263
    assert nodes._pixel_frames(prev_t) == prev_frames
    aligned_prev = {"samples": Nested([
        T(np.arange(16 * prev_t * h * w, dtype=np.float32
                    ).reshape(1, 16, prev_t, h, w)),
        T(np.arange(2 * prev_audio_t, dtype=np.float32
                    ).reshape(1, 1, 2, prev_audio_t)),
    ])}
    (aligned_path,) = saver.save(
        aligned_prev, "h3_context/aligned", clip_index=1,
        sample_length=158, trim_frames=22, export_frames=124)
    forced_first, forced_end, forced_path, forced_found = loader.load(
        aligned_path, clip_index=0, missing_ok=True, current_clip_index=1)
    assert forced_first is None and forced_found is False
    assert (forced_end, forced_path) == (0, "")
    assert loader.IS_CHANGED(
        aligned_path, clip_index=0, current_clip_index=1) == "first-clip"
    aligned_loaded, aligned_end, _, aligned_found = loader.load(
        aligned_path, clip_index=1)
    assert aligned_found is True
    assert aligned_end == 146, aligned_end
    captured.clear()
    _, _, previous_tail_trim = node.apply(
        conditioning=[["c", {}]], vae=VAE(), latent=target,
        context_length="22", audio_context_length=24,
        context_latent=aligned_loaded, context_end_frame=aligned_end)
    assert previous_tail_trim == 5, previous_tail_trim
    aligned_blocks = [kf["latent"] for kf in captured["minimax_keyframes"]]
    src_aligned = aligned_loaded["samples"][0].a
    assert np.array_equal(aligned_blocks[0].a[0, :, 0],
                          src_aligned[0, :, 35])
    assert np.array_equal(aligned_blocks[-1].a[0, :, 0],
                          src_aligned[0, :, 41])
    aligned_audio = captured["minimax_refs"][0]["audio_latent"]
    assert np.array_equal(
        aligned_audio.a[..., -1], aligned_loaded["samples"][1].a[..., 234])
    tail_trim = nodes.MiniMaxH3MotionContextTrimExportTail()
    prev_export = T(np.zeros((124, 8, 8, 3), dtype=np.float32))
    trimmed_export, _ = tail_trim.trim(prev_export, previous_tail_trim)
    assert trimmed_export.shape[0] == 119
    updater = nodes.MiniMaxH3MotionContextUpdateHandoff()
    (updated_path,) = updater.update(aligned_path, previous_tail_trim)
    assert updated_path == aligned_path
    _, updated_end, _, _ = loader.load(aligned_path, clip_index=1)
    assert updated_end == 141, updated_end
    stat_before = os.stat(aligned_path).st_mtime_ns
    (unchanged_path,) = updater.update(aligned_path, 0)
    assert unchanged_path == aligned_path
    assert os.stat(aligned_path).st_mtime_ns == stat_before
    # First clip: the Load Latent branch is bypassed, while this output node
    # can still execute with an unresolved path and a zero trim.
    (first_run_path,) = updater.update("", 0)
    assert first_run_path == ""
    (unset_path,) = updater.update(None, None)
    assert unset_path == ""
    missing_latent, missing_end, missing_path, missing_found = loader.load(
        "h3_context/does-not-exist", clip_index=1, missing_ok=True)
    assert missing_latent is None
    assert (missing_end, missing_path, missing_found) == (0, "", False)
    try:
        loader.load("h3_context/does-not-exist", clip_index=2,
                    missing_ok=True, current_clip_index=3)
    except RuntimeError as exc:
        assert "queue probably ran clips out of order" in str(exc)
    else:
        raise AssertionError("a chained clip silently continued without context")
    try:
        updater.update("h3_context/does-not-exist", 1)
    except FileNotFoundError:
        pass
    else:
        raise AssertionError("missing latent with a real trim did not refuse")
    current_export, _ = nodes.MiniMaxH3MotionContextTrim().trim(
        T(np.zeros((158, 8, 8, 3), dtype=np.float32)), 22,
        target_frames=124)
    assert current_export.shape[0] == 124
    print("handoff check: export end 146 -> phase pin end 141, previous "
          "export trimmed 5f, handoff updated 146 -> 141, current decode "
          "cropped to 124f, audio sliced to the same instant")

    (p1,) = saver.save(prev, "h3_context/clip")
    time.sleep(0.02)
    prev2 = {"samples": Nested([
        prev["samples"].parts[0],
        T(prev["samples"].parts[1].a * 2.0),  # distinguishable content
    ])}
    (p2,) = saver.save(prev2, "h3_context/clip")
    assert p1 != p2
    loaded, loaded_end, _, _ = loader.load("h3_context")  # newest = p2
    parts = loaded["samples"]
    assert isinstance(parts, list) and len(parts) == 2
    captured.clear()
    node.apply(
        conditioning=[["c", {}]], vae=VAE(), latent=target,
        context_frames=context, context_length="22",
        audio_context_length=22, context_latent=loaded)
    ref3 = captured["minimax_refs"][0]
    want = float(prev2["samples"].parts[1].a[0, 0, 0, -1])
    got = float(ref3["audio_latent"].a[0, 0, 0, -1])
    assert got == want, (got, want)  # newest save's content came through
    assert abs(ref3[nodes.MC_AUDIO_KEY] - 22.2) < 1e-6
    ic1 = loader.IS_CHANGED("h3_context")
    assert isinstance(ic1, str) and p2 in ic1  # cache keys on the real file
    print("save/load roundtrip: newest of 2 saves loaded, pinned, "
          "end_frame %.4f, cache key tracks the file" %
          ref3[nodes.MC_AUDIO_KEY])

    # retry safety with indexed slots: generating clip 3, re-rolling it
    # must overwrite slot 3 and always load slot 2, never its own save
    prevA = {"samples": Nested([prev["samples"].parts[0],
                                T(np.full((1, 32, 2, audio_t), 7.0,
                                          dtype=np.float32))])}
    prevB1 = {"samples": Nested([prev["samples"].parts[0],
                                 T(np.full((1, 32, 2, audio_t), 8.0,
                                           dtype=np.float32))])}
    prevB2 = {"samples": Nested([prev["samples"].parts[0],
                                 T(np.full((1, 32, 2, audio_t), 9.0,
                                           dtype=np.float32))])}
    (pa,) = saver.save(prevA, "h3_context/clip", clip_index=2)   # clip 2 ok
    assert pa.endswith("_00002.safetensors"), pa  # natural slot name
    time.sleep(0.02)
    (pb1,) = saver.save(prevB1, "h3_context/clip", clip_index=3)  # clip 3 try 1
    time.sleep(0.02)
    (pb2,) = saver.save(prevB2, "h3_context/clip", clip_index=3)  # re-roll
    assert pb1 == pb2 and pa != pb1  # re-roll overwrote its own slot
    # generating clip 3, continuing FROM clip 2: loader index is 2, literally
    l3, l3_end, _, _ = loader.load("h3_context", clip_index=2)
    got = float(l3["samples"][1].a[0, 0, 0, 0])
    assert got == 7.0, got  # clip 2's latent, NOT the rejected attempt (8/9)
    # newest-file mode would have returned the reject: prove the hazard
    lnew, _, _, _ = loader.load("h3_context", clip_index=0)
    assert float(lnew["samples"][1].a[0, 0, 0, 0]) == 9.0
    # asking for a slot that was never saved says so plainly
    try:
        loader.load("h3_context", clip_index=7)
    except FileNotFoundError as e:
        assert "no saved latent for clip 7" in str(e)
    else:
        raise AssertionError("missing slot did not refuse")
    # an auto-numbered near-miss (trailing underscore) is never matched,
    # and the error explains the rename
    (pauto,) = saver.save(prevA, "h3_context/clip", clip_index=0)
    assert pauto.endswith("_.safetensors"), pauto
    import re as _re
    runno = int(_re.search(r"_(\d{5})_\.safetensors$", pauto).group(1))
    try:
        loader.load("h3_context", clip_index=runno)
    except FileNotFoundError as e:
        assert "trailing underscore" in str(e) and "rename" in str(e), str(e)
    else:
        raise AssertionError("auto-numbered file was matched by index")
    print("indexed slots: re-roll overwrites its slot, loads previous "
          "clip's latent; auto mode confirmed to return the reject")

    print("smoke test passed")


if __name__ == "__main__":
    main()
